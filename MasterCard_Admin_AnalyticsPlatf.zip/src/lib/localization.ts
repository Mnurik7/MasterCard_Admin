// Localization System for MasterCard Analytics Platform
// Supports: Russian (ru), Kazakh (kz), English (en)

export type Language = 'ru' | 'kz' | 'en';

export const translations = {
  // Navigation & Layout
  'nav.dashboard': {
    ru: 'Обзор',
    kz: 'Шолу',
    en: 'Dashboard'
  },
  'nav.chat': {
    ru: 'Чат-аналитика',
    kz: 'Чат-аналитика',
    en: 'Chat Analytics'
  },
  'nav.transactions': {
    ru: 'Транзакции',
    kz: 'Транзакциялар',
    en: 'Transactions'
  },
  'nav.reports': {
    ru: 'Отчёты',
    kz: 'Есептер',
    en: 'Reports'
  },
  'nav.notes': {
    ru: 'Заметки',
    kz: 'Ескертулер',
    en: 'Notes'
  },
  'nav.alerts': {
    ru: 'Уведомления',
    kz: 'Хабарландырулар',
    en: 'Alerts'
  },
  'nav.admin': {
    ru: 'Администрирование',
    kz: 'Әкімшілік',
    en: 'Administration'
  },
  'nav.settings': {
    ru: 'Настройки',
    kz: 'Баптаулар',
    en: 'Settings'
  },

  // Dashboard
  'dashboard.title': {
    ru: 'Обзор транзакций',
    kz: 'Транзакциялар шолу',
    en: 'Transaction Overview'
  },
  'dashboard.greeting': {
    ru: 'Добро пожаловать',
    kz: 'Қош келдіңіз',
    en: 'Welcome'
  },
  'dashboard.quickActions': {
    ru: 'Быстрые действия',
    kz: 'Жылдам әрекеттер',
    en: 'Quick Actions'
  },
  'dashboard.categories': {
    ru: 'Категории',
    kz: 'Санаттар',
    en: 'Categories'
  },
  'dashboard.merchants': {
    ru: 'Мерчанты',
    kz: 'Мерчанттар',
    en: 'Merchants'
  },
  'dashboard.geography': {
    ru: 'География',
    kz: 'География',
    en: 'Geography'
  },
  'dashboard.recentQueries': {
    ru: 'Последние запросы',
    kz: 'Соңғы сұраулар',
    en: 'Recent Queries'
  },
  'dashboard.insightFeed': {
    ru: 'Инсайты',
    kz: 'Түсініктер',
    en: 'Insights'
  },
  'dashboard.viewFullReport': {
    ru: 'Открыть полный отчёт',
    kz: 'Толық есепті ашу',
    en: 'View Full Report'
  },

  // KPI Cards
  'kpi.totalSpend': {
    ru: 'Общие расходы',
    kz: 'Жалпы шығындар',
    en: 'Total Spend'
  },
  'kpi.transactionCount': {
    ru: 'Транзакций',
    kz: 'Транзакциялар',
    en: 'Transactions'
  },
  'kpi.topCategory': {
    ru: 'Топ категория',
    kz: 'Үздік санат',
    en: 'Top Category'
  },
  'kpi.avgTicket': {
    ru: 'Средний чек',
    kz: 'Орташа чек',
    en: 'Average Ticket'
  },

  // Chat
  'chat.title': {
    ru: 'Аналитический ассистент',
    kz: 'Аналитикалық көмекші',
    en: 'Analytics Assistant'
  },
  'chat.placeholder': {
    ru: 'Спросите об аналитике, например: «Траты по категориям за октябрь»',
    kz: 'Аналитика туралы сұраңыз, мысалы: «Қазан айындағы санаттар бойынша шығындар»',
    en: 'Ask about analytics, e.g.: "Spend by category for October"'
  },
  'chat.voiceInput': {
    ru: 'Голосовой ввод',
    kz: 'Дауыстық енгізу',
    en: 'Voice Input'
  },
  'chat.showSQL': {
    ru: 'Показать SQL',
    kz: 'SQL көрсету',
    en: 'Show SQL'
  },
  'chat.listening': {
    ru: 'Слушаю...',
    kz: 'Тыңдап жатырмын...',
    en: 'Listening...'
  },
  'chat.processing': {
    ru: 'Обрабатываю...',
    kz: 'Өңдеу...',
    en: 'Processing...'
  },
  'chat.suggestedQueries': {
    ru: 'Популярные запросы',
    kz: 'Танымал сұраулар',
    en: 'Suggested Queries'
  },

  // Buttons & Actions
  'button.save': {
    ru: 'Сохранить',
    kz: 'Сақтау',
    en: 'Save'
  },
  'button.export': {
    ru: 'Экспорт',
    kz: 'Экспорт',
    en: 'Export'
  },
  'button.cancel': {
    ru: 'Отмена',
    kz: 'Болдырмау',
    en: 'Cancel'
  },
  'button.confirm': {
    ru: 'Подтвердить',
    kz: 'Растау',
    en: 'Confirm'
  },
  'button.delete': {
    ru: 'Удалить',
    kz: 'Жою',
    en: 'Delete'
  },
  'button.edit': {
    ru: 'Изменить',
    kz: 'Өзгерту',
    en: 'Edit'
  },
  'button.addNote': {
    ru: 'Добавить заметку',
    kz: 'Ескерту қосу',
    en: 'Add Note'
  },
  'button.createAlert': {
    ru: 'Создать оповещение',
    kz: 'Хабарландыру жасау',
    en: 'Create Alert'
  },
  'button.comparePerids': {
    ru: 'Сравнить периоды',
    kz: 'Кезеңдерді салыстыру',
    en: 'Compare Periods'
  },
  'button.viewDetails': {
    ru: 'Подробнее',
    kz: 'Толығырақ',
    en: 'View Details'
  },

  // Notes
  'note.title': {
    ru: 'Заметки',
    kz: 'Ескертулер',
    en: 'Notes'
  },
  'note.add': {
    ru: 'Добавить заметку',
    kz: 'Ескерту қосу',
    en: 'Add Note'
  },
  'note.addPlaceholder': {
    ru: 'Добавьте заметку...',
    kz: 'Ескерту қосыңыз...',
    en: 'Add a note...'
  },
  'note.personal': {
    ru: 'Личные',
    kz: 'Жеке',
    en: 'Personal'
  },
  'note.shared': {
    ru: 'Командные',
    kz: 'Команда',
    en: 'Shared'
  },
  'note.pinned': {
    ru: 'Закреплённые',
    kz: 'Бекітілген',
    en: 'Pinned'
  },
  'note.search': {
    ru: 'Поиск заметок',
    kz: 'Ескертулерді іздеу',
    en: 'Search notes'
  },

  // Transactions
  'transaction.date': {
    ru: 'Дата',
    kz: 'Күні',
    en: 'Date'
  },
  'transaction.amount': {
    ru: 'Сумма',
    kz: 'Сома',
    en: 'Amount'
  },
  'transaction.merchant': {
    ru: 'Мерчант',
    kz: 'Мерчант',
    en: 'Merchant'
  },
  'transaction.category': {
    ru: 'Категория',
    kz: 'Санат',
    en: 'Category'
  },
  'transaction.region': {
    ru: 'Регион',
    kz: 'Өңір',
    en: 'Region'
  },
  'transaction.cardType': {
    ru: 'Тип карты',
    kz: 'Карта түрі',
    en: 'Card Type'
  },
  'transaction.status': {
    ru: 'Статус',
    kz: 'Мәртебе',
    en: 'Status'
  },

  // Alerts
  'alert.title': {
    ru: 'Уведомления',
    kz: 'Хабарландырулар',
    en: 'Alerts'
  },
  'alert.createNew': {
    ru: 'Создать оповещение',
    kz: 'Хабарландыру жасау',
    en: 'Create Alert'
  },
  'alert.anomaly': {
    ru: 'Обнаружена аномалия',
    kz: 'Ауытқу анықталды',
    en: 'Anomaly Detected'
  },

  // Admin
  'admin.title': {
    ru: 'Администрирование',
    kz: 'Әкімшілік',
    en: 'Administration'
  },
  'admin.users': {
    ru: 'Пользователи',
    kz: 'Пайдаланушылар',
    en: 'Users'
  },
  'admin.roles': {
    ru: 'Роли',
    kz: 'Рөлдер',
    en: 'Roles'
  },
  'admin.auditLog': {
    ru: 'Журнал действий',
    kz: 'Іс-әрекеттер журналы',
    en: 'Audit Log'
  },
  'admin.integrations': {
    ru: 'Интеграции',
    kz: 'Интеграциялар',
    en: 'Integrations'
  },
  'admin.dataHealth': {
    ru: 'Качество данных',
    kz: 'Деректер сапасы',
    en: 'Data Health'
  },

  // Common
  'common.search': {
    ru: 'Поиск',
    kz: 'Іздеу',
    en: 'Search'
  },
  'common.filter': {
    ru: 'Фильтр',
    kz: 'Сүзгі',
    en: 'Filter'
  },
  'common.sort': {
    ru: 'Сортировка',
    kz: 'Сұрыптау',
    en: 'Sort'
  },
  'common.loading': {
    ru: 'Загрузка...',
    kz: 'Жүктелуде...',
    en: 'Loading...'
  },
  'common.error': {
    ru: 'Ошибка',
    kz: 'Қате',
    en: 'Error'
  },
  'common.success': {
    ru: 'Успешно',
    kz: 'Сәтті',
    en: 'Success'
  },
  'common.noData': {
    ru: 'Нет данных',
    kz: 'Деректер жоқ',
    en: 'No data'
  },
};

export function useTranslation() {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: keyof typeof translations): string => {
    const translation = translations[key];
    return translation ? translation[language] : key;
  };

  const changeLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
  };

  // Load language from localStorage on mount
  if (typeof window !== 'undefined') {
    const savedLang = localStorage.getItem('language') as Language;
    if (savedLang && language !== savedLang) {
      setLanguage(savedLang);
    }
  }

  return { t, language, changeLanguage };
}

// Helper function for direct translation
export function translate(key: keyof typeof translations, lang: Language): string {
  const translation = translations[key];
  return translation ? translation[lang] : key;
}

import { useState } from 'react';
