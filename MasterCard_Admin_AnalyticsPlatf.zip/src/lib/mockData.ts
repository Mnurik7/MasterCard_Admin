// Mock Data for MasterCard Analytics Platform

export interface Transaction {
  id: string;
  date: string;
  amount: number;
  currency: string;
  category: string;
  mcc: string;
  merchant: string;
  region: string;
  cardType: 'corporate' | 'personal';
  customerId: string;
  status: 'completed' | 'pending' | 'declined';
}

export interface KPIData {
  totalSpend: number;
  transactionCount: number;
  topCategory: string;
  avgTicket: number;
  change: number; // percentage
}

export interface Insight {
  id: string;
  title: string;
  description: string;
  type: 'anomaly' | 'trend' | 'alert' | 'info';
  timestamp: string;
  priority: 'high' | 'medium' | 'low';
}

export interface Note {
  id: string;
  content: string;
  author: string;
  timestamp: string;
  isPinned: boolean;
  isShared: boolean;
  tags: string[];
  linkedTo?: {
    type: 'transaction' | 'report' | 'dashboard';
    id: string;
  };
}

// Generate mock transactions
export function generateMockTransactions(count: number = 100): Transaction[] {
  const categories = [
    'Travel', 'Food & Dining', 'Shopping', 'Entertainment', 
    'Healthcare', 'Utilities', 'Transport', 'Services', 'Education'
  ];
  const merchants = [
    'Airline Emirates', 'Hilton Hotels', 'Starbucks', 'Amazon',
    'Apple Store', 'Shell Gas', 'Netflix', 'Spotify', 'Uber',
    'Walmart', 'Target', 'Best Buy', 'McDonald\'s', 'KFC'
  ];
  const regions = ['North America', 'Europe', 'Asia', 'Middle East', 'Latin America'];
  
  const transactions: Transaction[] = [];
  const now = new Date();
  
  for (let i = 0; i < count; i++) {
    const daysAgo = Math.floor(Math.random() * 90);
    const date = new Date(now);
    date.setDate(date.getDate() - daysAgo);
    
    transactions.push({
      id: `TXN-${String(i + 1).padStart(6, '0')}`,
      date: date.toISOString().split('T')[0],
      amount: Math.floor(Math.random() * 5000) + 10,
      currency: 'USD',
      category: categories[Math.floor(Math.random() * categories.length)],
      mcc: String(5000 + Math.floor(Math.random() * 3000)),
      merchant: merchants[Math.floor(Math.random() * merchants.length)],
      region: regions[Math.floor(Math.random() * regions.length)],
      cardType: Math.random() > 0.3 ? 'corporate' : 'personal',
      customerId: `CUST-${String(Math.floor(Math.random() * 1000)).padStart(4, '0')}`,
      status: Math.random() > 0.1 ? 'completed' : (Math.random() > 0.5 ? 'pending' : 'declined')
    });
  }
  
  return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

// Mock KPI data
export const mockKPIData: KPIData = {
  totalSpend: 12847563,
  transactionCount: 45789,
  topCategory: 'Travel',
  avgTicket: 280.54,
  change: 8.3
};

// Mock insights from Gemini
export const mockInsights: Insight[] = [
  {
    id: 'INS-001',
    title: 'Travel spending increased by 23%',
    description: 'Travel category spending grew by 23% in the Asia region. Possible cause: seasonal promotional campaign.',
    type: 'trend',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    priority: 'medium'
  },
  {
    id: 'INS-002',
    title: 'Unusual transaction pattern detected',
    description: 'Multiple high-value transactions from merchant "Luxury Store" in North America. Recommend review.',
    type: 'anomaly',
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    priority: 'high'
  },
  {
    id: 'INS-003',
    title: 'Average ticket size decreased',
    description: 'Shopping category average ticket decreased by 12% compared to last month.',
    type: 'alert',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    priority: 'low'
  },
  {
    id: 'INS-004',
    title: 'Peak transaction time: 2-4 PM',
    description: 'Most corporate card transactions occur between 2-4 PM on weekdays.',
    type: 'info',
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    priority: 'low'
  }
];

// Mock notes
export const mockNotes: Note[] = [
  {
    id: 'NOTE-001',
    content: 'Reviewed Q4 travel expenses - approved for next quarter budget',
    author: 'Sarah Johnson',
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    isPinned: true,
    isShared: true,
    tags: ['budget', 'travel', 'q4']
  },
  {
    id: 'NOTE-002',
    content: 'Need to follow up on the anomaly in transaction TXN-000234',
    author: 'John Smith',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    isPinned: false,
    isShared: false,
    tags: ['follow-up', 'anomaly'],
    linkedTo: { type: 'transaction', id: 'TXN-000234' }
  },
  {
    id: 'NOTE-003',
    content: 'Merchant "Amazon" showing consistent growth - consider partnership opportunities',
    author: 'Emily Davis',
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    isPinned: true,
    isShared: true,
    tags: ['partnership', 'growth']
  }
];

// Mock chart data
export const mockSpendByCategory = [
  { category: 'Travel', amount: 3245678, percentage: 25.3 },
  { category: 'Shopping', amount: 2456123, percentage: 19.1 },
  { category: 'Food & Dining', amount: 1987654, percentage: 15.5 },
  { category: 'Entertainment', amount: 1456789, percentage: 11.3 },
  { category: 'Transport', amount: 1234567, percentage: 9.6 },
  { category: 'Utilities', amount: 987654, percentage: 7.7 },
  { category: 'Healthcare', amount: 765432, percentage: 6.0 },
  { category: 'Services', amount: 543210, percentage: 4.2 },
  { category: 'Education', amount: 170456, percentage: 1.3 }
];

export const mockSpendTrend = [
  { month: 'Jan', spend: 8234567, transactions: 35678 },
  { month: 'Feb', spend: 8567890, transactions: 37234 },
  { month: 'Mar', spend: 9123456, transactions: 38901 },
  { month: 'Apr', spend: 9456789, transactions: 40123 },
  { month: 'May', spend: 10234567, transactions: 42345 },
  { month: 'Jun', spend: 10987654, transactions: 44567 },
  { month: 'Jul', spend: 11456789, transactions: 45789 },
  { month: 'Aug', spend: 11987654, transactions: 47234 },
  { month: 'Sep', spend: 12234567, transactions: 48901 },
  { month: 'Oct', spend: 12847563, transactions: 45789 }
];

export const mockRegionalData = [
  { region: 'North America', spend: 4234567, transactions: 18234, growth: 5.2 },
  { region: 'Europe', spend: 3456789, transactions: 15678, growth: 7.8 },
  { region: 'Asia', spend: 2987654, transactions: 12345, growth: 12.3 },
  { region: 'Middle East', spend: 1456789, transactions: 6789, growth: 9.1 },
  { region: 'Latin America', spread: 711764, transactions: 4743, growth: 3.4 }
];

// Mock suggested queries
export const mockSuggestedQueries = [
  'Show spend by category for October',
  'Top 10 merchants by transaction volume',
  'Compare this month vs last month',
  'Declined transactions in the last 7 days',
  'Average ticket size by region',
  'Corporate vs personal card spending'
];

// Mock chat responses
export function generateMockChatResponse(query: string) {
  const responses: Record<string, any> = {
    'category': {
      type: 'chart',
      data: mockSpendByCategory,
      chartType: 'bar',
      sql: 'SELECT category, SUM(amount) as total FROM transactions WHERE date >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY category ORDER BY total DESC'
    },
    'merchant': {
      type: 'table',
      data: generateMockTransactions(10),
      sql: 'SELECT merchant, COUNT(*) as count, SUM(amount) as total FROM transactions GROUP BY merchant ORDER BY total DESC LIMIT 10'
    },
    'trend': {
      type: 'chart',
      data: mockSpendTrend,
      chartType: 'line',
      sql: 'SELECT DATE_FORMAT(date, "%Y-%m") as month, SUM(amount) as spend, COUNT(*) as transactions FROM transactions GROUP BY month'
    },
    'region': {
      type: 'chart',
      data: mockRegionalData,
      chartType: 'bar',
      sql: 'SELECT region, SUM(amount) as spend FROM transactions GROUP BY region'
    }
  };
  
  // Simple keyword matching
  const lowerQuery = query.toLowerCase();
  if (lowerQuery.includes('category') || lowerQuery.includes('categor')) {
    return responses['category'];
  } else if (lowerQuery.includes('merchant') || lowerQuery.includes('мерчант')) {
    return responses['merchant'];
  } else if (lowerQuery.includes('trend') || lowerQuery.includes('динамик')) {
    return responses['trend'];
  } else if (lowerQuery.includes('region') || lowerQuery.includes('географ')) {
    return responses['region'];
  }
  
  return responses['category']; // default
}

// Format currency
export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

// Format number with K/M suffix
export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

// Format percentage
export function formatPercentage(num: number): string {
  return (num >= 0 ? '+' : '') + num.toFixed(1) + '%';
}

// Format date
export function formatDate(dateString: string, locale: string = 'en-US'): string {
  const date = new Date(dateString);
  return date.toLocaleDateString(locale, { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

// Format relative time
export function formatRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDate(dateString);
}
