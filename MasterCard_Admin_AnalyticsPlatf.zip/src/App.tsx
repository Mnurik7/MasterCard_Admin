import { useState, useEffect } from 'react';
import { TopBar } from './components/layout/TopBar';
import { Sidebar } from './components/layout/Sidebar';
import { MobileNav } from './components/layout/MobileNav';
import { NotesBar } from './components/dashboard/NotesBar';
import { DashboardPage } from './pages/DashboardPage';
import { ChatPage } from './pages/ChatPage';
import { TransactionsPage } from './pages/TransactionsPage';
import { NotesPage } from './pages/NotesPage';
import { AdminPage } from './pages/AdminPage';
import { ReportsPage } from './pages/ReportsPage';
import { AlertsPage } from './pages/AlertsPage';
import { ChatWidget } from './components/chat/ChatWidget';
import { ToastProvider } from './components/common/ToastProvider';
import { MessageSquare, X } from 'lucide-react';
import { Button } from './components/ui/button';

type Page = 'dashboard' | 'chat' | 'transactions' | 'reports' | 'notes' | 'alerts' | 'admin' | 'settings';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showChatWidget, setShowChatWidget] = useState(false);
  const [showNotesPanel, setShowNotesPanel] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    // Hide chat widget when navigating to chat page
    if (page === 'chat') {
      setShowChatWidget(false);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage onNavigate={handleNavigate} />;
      case 'chat':
        return <ChatPage />;
      case 'transactions':
        return <TransactionsPage />;
      case 'notes':
        return <NotesPage />;
      case 'admin':
        return <AdminPage />;
      case 'reports':
        return <ReportsPage />;
      case 'alerts':
        return <AlertsPage />;
      case 'settings':
        return <SettingsPlaceholder />;
      default:
        return <DashboardPage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-[var(--color-background)]">
      <ToastProvider />
      
      {/* Top Bar */}
      <TopBar onOpenNotes={() => setShowNotesPanel(!showNotesPanel)} />

      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        {!isMobile && (
          <Sidebar
            currentPage={currentPage}
            onNavigate={handleNavigate}
            collapsed={sidebarCollapsed}
            onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          />
        )}

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Notes Bar - shown on dashboard */}
          {currentPage === 'dashboard' && (
            <NotesBar onAddNote={() => handleNavigate('notes')} />
          )}

          {/* Page Content */}
          <div className="flex-1 overflow-y-auto pb-20 md:pb-0">
            {renderPage()}
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      {isMobile && (
        <MobileNav currentPage={currentPage} onNavigate={handleNavigate} />
      )}

      {/* Floating Chat Widget Button (shown on non-chat pages) */}
      {currentPage !== 'chat' && !showChatWidget && !isMobile && (
        <Button
          size="icon"
          onClick={() => setShowChatWidget(true)}
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-xl gradient-brand hover:shadow-2xl transition-all z-40"
        >
          <MessageSquare className="w-6 h-6" />
        </Button>
      )}

      {/* Floating Chat Widget */}
      {showChatWidget && currentPage !== 'chat' && !isMobile && (
        <div className="fixed bottom-6 right-6 z-50">
          <ChatWidget
            compact
            onExpand={() => {
              setShowChatWidget(false);
              handleNavigate('chat');
            }}
            onClose={() => setShowChatWidget(false)}
          />
        </div>
      )}
    </div>
  );
}

// Placeholder components for pages not yet implemented
function SettingsPlaceholder() {
  return (
    <div className="p-6">
      <h1 className="mb-2">Settings</h1>
      <p className="text-[var(--color-text-secondary)]">
        Manage your account, preferences, and integrations.
      </p>
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card-elevated p-6">
          <h4 className="mb-4">Profile Settings</h4>
          <div className="space-y-3">
            <div>
              <label className="text-sm text-[var(--color-text-secondary)]">Name</label>
              <div className="font-medium">Sarah Johnson</div>
            </div>
            <div>
              <label className="text-sm text-[var(--color-text-secondary)]">Email</label>
              <div className="font-medium">sarah.johnson@mastercard.com</div>
            </div>
            <div>
              <label className="text-sm text-[var(--color-text-secondary)]">Role</label>
              <div className="font-medium">Analytics Manager</div>
            </div>
          </div>
          <Button className="w-full mt-4">Edit Profile</Button>
        </div>

        <div className="card-elevated p-6">
          <h4 className="mb-4">Preferences</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Email Notifications</span>
              <input type="checkbox" defaultChecked className="w-4 h-4" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Push Notifications</span>
              <input type="checkbox" defaultChecked className="w-4 h-4" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Dark Mode</span>
              <input type="checkbox" className="w-4 h-4" />
            </div>
          </div>
          <Button variant="outline" className="w-full mt-4">Save Preferences</Button>
        </div>
      </div>
    </div>
  );
}

export default App;