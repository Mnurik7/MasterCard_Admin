import { Users, Shield, Activity, Database, Zap, CheckCircle, AlertCircle } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { useTranslation } from '../lib/localization';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../components/ui/table';

export function AdminPage() {
  const { t } = useTranslation();

  const users = [
    { id: 1, name: 'Sarah Johnson', email: 'sarah.j@mastercard.com', role: 'Admin', status: 'active' },
    { id: 2, name: 'John Smith', email: 'john.s@mastercard.com', role: 'Analyst', status: 'active' },
    { id: 3, name: 'Emily Davis', email: 'emily.d@mastercard.com', role: 'Viewer', status: 'active' },
    { id: 4, name: 'Michael Brown', email: 'michael.b@mastercard.com', role: 'Analyst', status: 'inactive' },
  ];

  const roles = [
    { name: 'Admin', permissions: ['All'], users: 1, color: 'bg-[var(--color-error-500)]' },
    { name: 'Analyst', permissions: ['Read', 'Write', 'Export'], users: 3, color: 'bg-[var(--color-primary-500)]' },
    { name: 'Viewer', permissions: ['Read'], users: 5, color: 'bg-[var(--color-neutral-500)]' },
  ];

  const auditLogs = [
    { id: 1, user: 'Sarah Johnson', action: 'Exported transaction report', timestamp: '2m ago', type: 'export' },
    { id: 2, user: 'John Smith', action: 'Created alert for high-value transactions', timestamp: '15m ago', type: 'create' },
    { id: 3, user: 'Emily Davis', action: 'Updated note on TXN-000234', timestamp: '1h ago', type: 'update' },
    { id: 4, user: 'Sarah Johnson', action: 'Changed user role for Michael Brown', timestamp: '2h ago', type: 'admin' },
  ];

  const integrations = [
    { name: 'Gemini AI', status: 'connected', usage: '12.5K tokens today', health: 'healthy' },
    { name: 'Firebase Auth', status: 'connected', usage: '234 auth requests', health: 'healthy' },
    { name: 'Firestore', status: 'connected', usage: '1.2K reads, 345 writes', health: 'healthy' },
    { name: 'Cloud Functions', status: 'connected', usage: '567 invocations', health: 'warning' },
  ];

  const dataHealth = [
    { metric: 'Data Freshness', value: '< 5 minutes', status: 'healthy' },
    { metric: 'Query Performance', value: 'Avg 234ms', status: 'healthy' },
    { metric: 'Error Rate', value: '0.12%', status: 'healthy' },
    { metric: 'API Availability', value: '99.98%', status: 'healthy' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">{t('admin.title')}</h1>
        <p className="text-[var(--color-text-secondary)]">
          Manage users, roles, integrations, and monitor system health.
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card-elevated p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Total Users</div>
              <div className="font-semibold text-2xl">127</div>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[var(--color-primary-100)] flex items-center justify-center">
              <Users className="w-5 h-5 text-[var(--color-primary-600)]" />
            </div>
          </div>
          <div className="text-xs text-[var(--color-success-600)]">
            +12 this month
          </div>
        </div>

        <div className="card-elevated p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Active Sessions</div>
              <div className="font-semibold text-2xl">89</div>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[var(--color-success-100)] flex items-center justify-center">
              <Activity className="w-5 h-5 text-[var(--color-success-600)]" />
            </div>
          </div>
          <div className="text-xs text-[var(--color-text-tertiary)]">
            70% of total users
          </div>
        </div>

        <div className="card-elevated p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <div className="text-sm text-[var(--color-text-tertiary)] mb-1">API Calls Today</div>
              <div className="font-semibold text-2xl">15.2K</div>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[var(--color-info-100)] flex items-center justify-center">
              <Zap className="w-5 h-5 text-[var(--color-info-600)]" />
            </div>
          </div>
          <div className="text-xs text-[var(--color-success-600)]">
            +8% vs yesterday
          </div>
        </div>

        <div className="card-elevated p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <div className="text-sm text-[var(--color-text-tertiary)] mb-1">System Health</div>
              <div className="font-semibold text-2xl">99.8%</div>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[var(--color-success-100)] flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-[var(--color-success-600)]" />
            </div>
          </div>
          <div className="text-xs text-[var(--color-success-600)]">
            All systems operational
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="users" className="w-full">
        <TabsList>
          <TabsTrigger value="users">{t('admin.users')}</TabsTrigger>
          <TabsTrigger value="roles">{t('admin.roles')}</TabsTrigger>
          <TabsTrigger value="integrations">{t('admin.integrations')}</TabsTrigger>
          <TabsTrigger value="data">{t('admin.dataHealth')}</TabsTrigger>
          <TabsTrigger value="audit">{t('admin.auditLog')}</TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <div className="card-elevated overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell className="text-sm text-[var(--color-text-secondary)]">
                      {user.email}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{user.role}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={user.status === 'active' 
                        ? 'bg-[var(--color-success-100)] text-[var(--color-success-700)]'
                        : 'bg-[var(--color-neutral-200)] text-[var(--color-neutral-700)]'
                      }>
                        {user.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">{t('button.edit')}</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* Roles Tab */}
        <TabsContent value="roles" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {roles.map((role) => (
              <div key={role.name} className="card-elevated p-5">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h4 className="mb-1">{role.name}</h4>
                    <p className="text-sm text-[var(--color-text-tertiary)]">{role.users} users</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${role.color}`} />
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">Permissions:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {role.permissions.map((perm) => (
                      <Badge key={perm} variant="secondary" className="text-xs">
                        {perm}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full mt-4">
                  {t('button.edit')}
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {integrations.map((integration) => (
              <div key={integration.name} className="card-elevated p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="mb-1">{integration.name}</h4>
                    <p className="text-sm text-[var(--color-text-secondary)]">{integration.usage}</p>
                  </div>
                  <Badge className={
                    integration.health === 'healthy'
                      ? 'bg-[var(--color-success-100)] text-[var(--color-success-700)]'
                      : 'bg-[var(--color-warning-100)] text-[var(--color-warning-700)]'
                  }>
                    {integration.health}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[var(--color-success-500)] rounded-full" />
                  <span className="text-sm text-[var(--color-text-tertiary)]">{integration.status}</span>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Data Health Tab */}
        <TabsContent value="data" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {dataHealth.map((item) => (
              <div key={item.metric} className="card-elevated p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-sm text-[var(--color-text-tertiary)] mb-1">{item.metric}</div>
                    <div className="font-semibold text-xl">{item.value}</div>
                  </div>
                  <CheckCircle className="w-6 h-6 text-[var(--color-success-600)]" />
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Audit Log Tab */}
        <TabsContent value="audit" className="space-y-4">
          <div className="card-elevated overflow-hidden">
            <div className="p-4 border-b border-[var(--color-border)]">
              <h4>Recent Activity</h4>
            </div>
            <div className="divide-y divide-[var(--color-border)]">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-4 hover:bg-[var(--color-surface-hover)] transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">{log.user}</span>
                        <Badge variant="secondary" className="text-xs">{log.type}</Badge>
                      </div>
                      <p className="text-sm text-[var(--color-text-secondary)]">{log.action}</p>
                    </div>
                    <span className="text-xs text-[var(--color-text-tertiary)]">{log.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
