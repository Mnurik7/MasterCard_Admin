import { useState } from 'react';
import { Download, Filter, StickyNote, MoreVertical, Search } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';
import { Badge } from '../components/ui/badge';
import { useTranslation } from '../lib/localization';
import { generateMockTransactions, formatCurrency, formatDate, Transaction } from '../lib/mockData';

export function TransactionsPage() {
  const { t, language } = useTranslation();
  const [transactions] = useState<Transaction[]>(generateMockTransactions(50));
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  const filteredTransactions = transactions.filter(tx =>
    tx.merchant.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tx.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tx.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const statusColors = {
    completed: 'bg-[var(--color-success-100)] text-[var(--color-success-700)]',
    pending: 'bg-[var(--color-warning-100)] text-[var(--color-warning-700)]',
    declined: 'bg-[var(--color-error-100)] text-[var(--color-error-700)]',
  };

  const cardTypeColors = {
    corporate: 'bg-[var(--color-primary-100)] text-[var(--color-primary-700)]',
    personal: 'bg-[var(--color-neutral-200)] text-[var(--color-neutral-700)]',
  };

  const handleAddNote = (transaction: Transaction) => {
    alert(`Add note for transaction: ${transaction.id}`);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">{t('nav.transactions')}</h1>
        <p className="text-[var(--color-text-secondary)]">
          View and analyze all transaction data with advanced filtering.
        </p>
      </div>

      {/* Filters & Actions */}
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="flex-1 max-w-md relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-tertiary)]" />
          <Input
            placeholder={`${t('common.search')}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" />
            {t('common.filter')}
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            {t('button.export')}
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="card-elevated overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>{t('transaction.date')}</TableHead>
                <TableHead>{t('transaction.merchant')}</TableHead>
                <TableHead>{t('transaction.category')}</TableHead>
                <TableHead>{t('transaction.region')}</TableHead>
                <TableHead>{t('transaction.cardType')}</TableHead>
                <TableHead className="text-right">{t('transaction.amount')}</TableHead>
                <TableHead>{t('transaction.status')}</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTransactions.slice(0, 20).map((tx) => (
                <TableRow 
                  key={tx.id}
                  className="hover:bg-[var(--color-surface-hover)] cursor-pointer"
                  onClick={() => setSelectedTransaction(tx)}
                >
                  <TableCell className="font-mono text-xs">{tx.id}</TableCell>
                  <TableCell className="text-sm">
                    {formatDate(tx.date, language === 'ru' ? 'ru-RU' : language === 'kz' ? 'kk-KZ' : 'en-US')}
                  </TableCell>
                  <TableCell className="font-medium">{tx.merchant}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="text-xs">
                      {tx.category}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-[var(--color-text-secondary)]">
                    {tx.region}
                  </TableCell>
                  <TableCell>
                    <Badge className={`text-xs ${cardTypeColors[tx.cardType]}`}>
                      {tx.cardType}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-semibold">
                    {formatCurrency(tx.amount, tx.currency)}
                  </TableCell>
                  <TableCell>
                    <Badge className={`text-xs ${statusColors[tx.status]}`}>
                      {tx.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleAddNote(tx)}>
                          <StickyNote className="w-4 h-4 mr-2" />
                          {t('button.addNote')}
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="w-4 h-4 mr-2" />
                          {t('button.export')}
                        </DropdownMenuItem>
                        <DropdownMenuItem>{t('button.viewDetails')}</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="border-t border-[var(--color-border)] p-4 flex items-center justify-between">
          <div className="text-sm text-[var(--color-text-secondary)]">
            Showing 1-20 of {filteredTransactions.length} transactions
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>

      {/* Transaction Details Modal */}
      {selectedTransaction && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedTransaction(null)}
        >
          <div 
            className="bg-[var(--color-surface)] rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <h3 className="mb-1">Transaction Details</h3>
                <p className="text-sm text-[var(--color-text-secondary)]">{selectedTransaction.id}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setSelectedTransaction(null)}>
                <span className="text-xl">×</span>
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Merchant</div>
                <div className="font-medium">{selectedTransaction.merchant}</div>
              </div>
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Amount</div>
                <div className="font-semibold text-lg">
                  {formatCurrency(selectedTransaction.amount, selectedTransaction.currency)}
                </div>
              </div>
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Category</div>
                <div>{selectedTransaction.category}</div>
              </div>
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Date</div>
                <div>{formatDate(selectedTransaction.date)}</div>
              </div>
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Region</div>
                <div>{selectedTransaction.region}</div>
              </div>
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Card Type</div>
                <Badge className={cardTypeColors[selectedTransaction.cardType]}>
                  {selectedTransaction.cardType}
                </Badge>
              </div>
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Status</div>
                <Badge className={statusColors[selectedTransaction.status]}>
                  {selectedTransaction.status}
                </Badge>
              </div>
              <div>
                <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Customer ID</div>
                <div className="font-mono text-sm">{selectedTransaction.customerId}</div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button className="flex-1 gap-2" onClick={() => handleAddNote(selectedTransaction)}>
                <StickyNote className="w-4 h-4" />
                {t('button.addNote')}
              </Button>
              <Button variant="outline" className="flex-1 gap-2">
                <Download className="w-4 h-4" />
                {t('button.export')}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
