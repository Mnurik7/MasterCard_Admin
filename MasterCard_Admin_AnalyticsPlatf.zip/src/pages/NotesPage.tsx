import { useState } from 'react';
import { Plus, Pin, Search, Tag, Users, User, Edit2, Trash2 } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { useTranslation } from '../lib/localization';
import { mockNotes, formatRelativeTime, Note } from '../lib/mockData';

export function NotesPage() {
  const { t } = useTranslation();
  const [notes, setNotes] = useState<Note[]>(mockNotes);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [newNoteContent, setNewNoteContent] = useState('');
  const [newNoteTags, setNewNoteTags] = useState('');

  const filteredNotes = notes.filter(note =>
    note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    note.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const pinnedNotes = filteredNotes.filter(n => n.isPinned);
  const personalNotes = filteredNotes.filter(n => !n.isShared && !n.isPinned);
  const sharedNotes = filteredNotes.filter(n => n.isShared && !n.isPinned);

  const handleAddNote = () => {
    if (!newNoteContent.trim()) return;

    const newNote: Note = {
      id: `NOTE-${Date.now()}`,
      content: newNoteContent,
      author: 'Sarah Johnson',
      timestamp: new Date().toISOString(),
      isPinned: false,
      isShared: false,
      tags: newNoteTags.split(',').map(t => t.trim()).filter(Boolean),
    };

    setNotes([newNote, ...notes]);
    setNewNoteContent('');
    setNewNoteTags('');
    setIsAddingNote(false);
  };

  const handleTogglePin = (noteId: string) => {
    setNotes(notes.map(note =>
      note.id === noteId ? { ...note, isPinned: !note.isPinned } : note
    ));
  };

  const handleDeleteNote = (noteId: string) => {
    setNotes(notes.filter(note => note.id !== noteId));
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">{t('note.title')}</h1>
        <p className="text-[var(--color-text-secondary)]">
          Capture insights, collaborate with your team, and link notes to transactions.
        </p>
      </div>

      {/* Search & Add */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-text-tertiary)]" />
          <Input
            placeholder={t('note.search')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button onClick={() => setIsAddingNote(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          {t('note.add')}
        </Button>
      </div>

      {/* Add Note Form */}
      {isAddingNote && (
        <div className="card-elevated p-6">
          <h4 className="mb-4">Create New Note</h4>
          <div className="space-y-4">
            <Textarea
              placeholder={t('note.addPlaceholder')}
              value={newNoteContent}
              onChange={(e) => setNewNoteContent(e.target.value)}
              rows={4}
            />
            <Input
              placeholder="Tags (comma separated)"
              value={newNoteTags}
              onChange={(e) => setNewNoteTags(e.target.value)}
            />
            <div className="flex gap-2">
              <Button onClick={handleAddNote}>{t('button.save')}</Button>
              <Button variant="outline" onClick={() => {
                setIsAddingNote(false);
                setNewNoteContent('');
                setNewNoteTags('');
              }}>
                {t('button.cancel')}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Notes Tabs */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="all">
            All ({filteredNotes.length})
          </TabsTrigger>
          <TabsTrigger value="personal">
            <User className="w-4 h-4 mr-2" />
            {t('note.personal')} ({personalNotes.length})
          </TabsTrigger>
          <TabsTrigger value="shared">
            <Users className="w-4 h-4 mr-2" />
            {t('note.shared')} ({sharedNotes.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          {pinnedNotes.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Pin className="w-4 h-4 text-[var(--color-primary-600)]" />
                <h4>{t('note.pinned')}</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {pinnedNotes.map((note) => (
                  <NoteCard
                    key={note.id}
                    note={note}
                    onTogglePin={handleTogglePin}
                    onDelete={handleDeleteNote}
                  />
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredNotes.filter(n => !n.isPinned).map((note) => (
              <NoteCard
                key={note.id}
                note={note}
                onTogglePin={handleTogglePin}
                onDelete={handleDeleteNote}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="personal" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {personalNotes.map((note) => (
              <NoteCard
                key={note.id}
                note={note}
                onTogglePin={handleTogglePin}
                onDelete={handleDeleteNote}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="shared" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sharedNotes.map((note) => (
              <NoteCard
                key={note.id}
                note={note}
                onTogglePin={handleTogglePin}
                onDelete={handleDeleteNote}
              />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Note Card Component
function NoteCard({ 
  note, 
  onTogglePin, 
  onDelete 
}: { 
  note: Note; 
  onTogglePin: (id: string) => void; 
  onDelete: (id: string) => void;
}) {
  return (
    <div className="card-elevated p-4 group hover:shadow-lg transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <p className="text-sm text-[var(--color-text-primary)] mb-2">
            {note.content}
          </p>
          <div className="flex items-center gap-2 text-xs text-[var(--color-text-tertiary)]">
            <span>{note.author}</span>
            <span>•</span>
            <span>{formatRelativeTime(note.timestamp)}</span>
          </div>
        </div>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={() => onTogglePin(note.id)}
          >
            <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-current text-[var(--color-primary-600)]' : ''}`} />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-[var(--color-error-600)]"
            onClick={() => onDelete(note.id)}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {note.tags.length > 0 && (
        <div className="flex gap-1.5 flex-wrap mb-3">
          {note.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs px-2 py-0 h-5">
              <Tag className="w-3 h-3 mr-1" />
              {tag}
            </Badge>
          ))}
        </div>
      )}

      {note.linkedTo && (
        <div className="text-xs text-[var(--color-primary-600)] bg-[var(--color-primary-50)] px-2 py-1 rounded">
          Linked to {note.linkedTo.type}: {note.linkedTo.id}
        </div>
      )}

      {note.isShared && (
        <div className="mt-3 pt-3 border-t border-[var(--color-border)] flex items-center gap-1 text-xs text-[var(--color-text-tertiary)]">
          <Users className="w-3.5 h-3.5" />
          <span>Shared with team</span>
        </div>
      )}
    </div>
  );
}
