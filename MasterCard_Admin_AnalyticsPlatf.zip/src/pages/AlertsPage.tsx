import { useState } from 'react';
import { Bell, Plus, TrendingUp, TrendingDown, AlertTriangle, Mail, Smartphone, Check } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { useTranslation } from '../lib/localization';
import { formatRelativeTime } from '../lib/mockData';

interface Alert {
  id: string;
  name: string;
  metric: string;
  condition: string;
  threshold: number;
  channels: ('email' | 'push' | 'in-app')[];
  isActive: boolean;
  lastTriggered?: string;
  triggeredCount: number;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'alert' | 'info' | 'success' | 'warning';
  timestamp: string;
  isRead: boolean;
}

export function AlertsPage() {
  const { t } = useTranslation();
  const [showCreateAlert, setShowCreateAlert] = useState(false);

  const alerts: Alert[] = [
    {
      id: 'ALT-001',
      name: 'High Transaction Volume',
      metric: 'Transaction Count',
      condition: 'greater than',
      threshold: 1000,
      channels: ['email', 'push'],
      isActive: true,
      lastTriggered: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      triggeredCount: 12
    },
    {
      id: 'ALT-002',
      name: 'Unusual Spending Pattern',
      metric: 'Spend Amount',
      condition: 'increases by',
      threshold: 25,
      channels: ['email', 'push', 'in-app'],
      isActive: true,
      lastTriggered: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      triggeredCount: 5
    },
    {
      id: 'ALT-003',
      name: 'Declined Transactions Spike',
      metric: 'Declined Rate',
      condition: 'greater than',
      threshold: 5,
      channels: ['email', 'in-app'],
      isActive: true,
      triggeredCount: 8
    },
    {
      id: 'ALT-004',
      name: 'Low Average Ticket',
      metric: 'Average Ticket',
      condition: 'less than',
      threshold: 200,
      channels: ['in-app'],
      isActive: false,
      lastTriggered: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      triggeredCount: 15
    }
  ];

  const notifications: Notification[] = [
    {
      id: 'NOT-001',
      title: 'High Transaction Volume Alert',
      message: 'Transaction count exceeded 1,000 in the last hour. Current: 1,234 transactions.',
      type: 'alert',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      isRead: false
    },
    {
      id: 'NOT-002',
      title: 'Unusual Spending Pattern Detected',
      message: 'Spending in the Travel category increased by 28% compared to last week.',
      type: 'warning',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      isRead: false
    },
    {
      id: 'NOT-003',
      title: 'Report Generated Successfully',
      message: 'Your monthly spend analysis report is ready for download.',
      type: 'success',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      isRead: true
    },
    {
      id: 'NOT-004',
      title: 'System Maintenance Scheduled',
      message: 'Analytics platform will undergo maintenance on Saturday, 2:00 AM - 4:00 AM.',
      type: 'info',
      timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      isRead: true
    }
  ];

  const notificationIcons = {
    alert: AlertTriangle,
    info: Bell,
    success: Check,
    warning: TrendingUp
  };

  const notificationColors = {
    alert: 'bg-[var(--color-error-100)] text-[var(--color-error-600)] border-[var(--color-error-200)]',
    info: 'bg-[var(--color-info-100)] text-[var(--color-info-600)] border-[var(--color-info-200)]',
    success: 'bg-[var(--color-success-100)] text-[var(--color-success-600)] border-[var(--color-success-200)]',
    warning: 'bg-[var(--color-warning-100)] text-[var(--color-warning-600)] border-[var(--color-warning-200)]'
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="mb-2">{t('alert.title')}</h1>
          <p className="text-[var(--color-text-secondary)]">
            Configure alerts and view all system notifications.
          </p>
        </div>
        <Button onClick={() => setShowCreateAlert(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          {t('alert.createNew')}
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Active Alerts</div>
          <div className="font-semibold text-2xl">{alerts.filter(a => a.isActive).length}</div>
        </div>
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Triggered Today</div>
          <div className="font-semibold text-2xl">7</div>
        </div>
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Unread</div>
          <div className="font-semibold text-2xl">{notifications.filter(n => !n.isRead).length}</div>
        </div>
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">This Month</div>
          <div className="font-semibold text-2xl">142</div>
        </div>
      </div>

      {/* Create Alert Form */}
      {showCreateAlert && (
        <div className="card-elevated p-6">
          <div className="flex items-center justify-between mb-4">
            <h3>Create New Alert</h3>
            <Button variant="ghost" size="sm" onClick={() => setShowCreateAlert(false)}>
              Cancel
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-[var(--color-text-secondary)] mb-2 block">Alert Name</label>
              <Input placeholder="Enter alert name" />
            </div>
            <div>
              <label className="text-sm text-[var(--color-text-secondary)] mb-2 block">Metric</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select metric" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="spend">Total Spend</SelectItem>
                  <SelectItem value="count">Transaction Count</SelectItem>
                  <SelectItem value="avg">Average Ticket</SelectItem>
                  <SelectItem value="declined">Declined Rate</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-[var(--color-text-secondary)] mb-2 block">Condition</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select condition" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gt">Greater than</SelectItem>
                  <SelectItem value="lt">Less than</SelectItem>
                  <SelectItem value="inc">Increases by %</SelectItem>
                  <SelectItem value="dec">Decreases by %</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-[var(--color-text-secondary)] mb-2 block">Threshold</label>
              <Input type="number" placeholder="Enter value" />
            </div>
          </div>
          <div className="mt-4">
            <label className="text-sm text-[var(--color-text-secondary)] mb-2 block">Notification Channels</label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="w-4 h-4" />
                <Mail className="w-4 h-4" />
                <span className="text-sm">Email</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="w-4 h-4" />
                <Smartphone className="w-4 h-4" />
                <span className="text-sm">Push</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="w-4 h-4" />
                <Bell className="w-4 h-4" />
                <span className="text-sm">In-App</span>
              </label>
            </div>
          </div>
          <div className="flex gap-2 mt-6">
            <Button>{t('button.save')}</Button>
            <Button variant="outline" onClick={() => setShowCreateAlert(false)}>
              {t('button.cancel')}
            </Button>
          </div>
        </div>
      )}

      {/* Tabs */}
      <Tabs defaultValue="notifications" className="w-full">
        <TabsList>
          <TabsTrigger value="notifications">
            Notifications ({notifications.filter(n => !n.isRead).length})
          </TabsTrigger>
          <TabsTrigger value="alerts">Configured Alerts ({alerts.length})</TabsTrigger>
        </TabsList>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4">
          <div className="flex items-center justify-between">
            <h4>Recent Notifications</h4>
            <Button variant="ghost" size="sm">Mark all as read</Button>
          </div>
          <div className="space-y-3">
            {notifications.map((notification) => {
              const Icon = notificationIcons[notification.type];
              return (
                <div
                  key={notification.id}
                  className={`card-elevated p-4 ${!notification.isRead ? 'border-l-4 border-l-[var(--color-primary-500)]' : ''}`}
                >
                  <div className="flex gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${notificationColors[notification.type]}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-1">
                        <h5 className={!notification.isRead ? 'font-semibold' : 'font-medium'}>
                          {notification.title}
                        </h5>
                        <span className="text-xs text-[var(--color-text-tertiary)]">
                          {formatRelativeTime(notification.timestamp)}
                        </span>
                      </div>
                      <p className="text-sm text-[var(--color-text-secondary)]">
                        {notification.message}
                      </p>
                      {!notification.isRead && (
                        <Button variant="ghost" size="sm" className="mt-2 h-7 text-xs">
                          Mark as read
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        {/* Alerts Tab */}
        <TabsContent value="alerts" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {alerts.map((alert) => (
              <div key={alert.id} className="card-elevated p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="mb-1">{alert.name}</h4>
                    <p className="text-sm text-[var(--color-text-secondary)]">
                      {alert.metric} {alert.condition} {alert.threshold}{alert.condition.includes('by') ? '%' : ''}
                    </p>
                  </div>
                  <Badge className={alert.isActive 
                    ? 'bg-[var(--color-success-100)] text-[var(--color-success-700)]'
                    : 'bg-[var(--color-neutral-200)] text-[var(--color-neutral-700)]'
                  }>
                    {alert.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-[var(--color-text-tertiary)]">Channels:</span>
                    <div className="flex gap-1">
                      {alert.channels.map((channel) => (
                        <Badge key={channel} variant="secondary" className="text-xs">
                          {channel === 'email' && <Mail className="w-3 h-3 mr-1" />}
                          {channel === 'push' && <Smartphone className="w-3 h-3 mr-1" />}
                          {channel === 'in-app' && <Bell className="w-3 h-3 mr-1" />}
                          {channel}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="text-sm text-[var(--color-text-tertiary)]">
                    Triggered {alert.triggeredCount} times
                    {alert.lastTriggered && ` • Last: ${formatRelativeTime(alert.lastTriggered)}`}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    {t('button.edit')}
                  </Button>
                  <Button 
                    variant={alert.isActive ? 'outline' : 'default'}
                    size="sm" 
                    className="flex-1"
                  >
                    {alert.isActive ? 'Disable' : 'Enable'}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
