import { DollarSign, Receipt, TrendingUp, CreditCard } from 'lucide-react';
import { KPICard } from '../components/dashboard/KPICard';
import { InsightCard } from '../components/dashboard/InsightCard';
import { QuickActions } from '../components/dashboard/QuickActions';
import { Button } from '../components/ui/button';
import { useTranslation } from '../lib/localization';
import { mockKPIData, mockInsights, formatCurrency, formatNumber } from '../lib/mockData';

interface DashboardPageProps {
  onNavigate?: (page: string) => void;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { t } = useTranslation();

  const kpiCards = [
    {
      title: t('kpi.totalSpend'),
      value: formatCurrency(mockKPIData.totalSpend),
      change: mockKPIData.change,
      icon: <DollarSign className="w-5 h-5" />,
      trend: [100, 120, 115, 140, 135, 160, 155, 180, 175, 200],
    },
    {
      title: t('kpi.transactionCount'),
      value: formatNumber(mockKPIData.transactionCount),
      change: 5.2,
      icon: <Receipt className="w-5 h-5" />,
      trend: [80, 85, 90, 95, 88, 92, 98, 105, 100, 110],
    },
    {
      title: t('kpi.topCategory'),
      value: mockKPIData.topCategory,
      subtitle: '25.3% of total',
      icon: <TrendingUp className="w-5 h-5" />,
    },
    {
      title: t('kpi.avgTicket'),
      value: `$${mockKPIData.avgTicket.toFixed(2)}`,
      change: -2.1,
      icon: <CreditCard className="w-5 h-5" />,
      trend: [120, 115, 118, 110, 112, 108, 105, 102, 100, 98],
    },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Greeting */}
      <div className="mb-6">
        <h1 className="mb-2">{t('dashboard.greeting')}, Sarah!</h1>
        <p className="text-[var(--color-text-secondary)]">
          Here's your transaction analytics overview for today.
        </p>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="mb-4">{t('dashboard.quickActions')}</h3>
        <QuickActions onAction={(action) => {
          if (action === 'categories' || action === 'merchants' || action === 'geography') {
            onNavigate?.('chat');
          } else if (action === 'reports') {
            onNavigate?.('reports');
          }
        }} />
      </div>

      {/* KPI Cards */}
      <div>
        <h3 className="mb-4">Key Metrics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiCards.map((card, idx) => (
            <KPICard
              key={idx}
              {...card}
              compact
              onClick={() => onNavigate?.('transactions')}
            />
          ))}
        </div>
      </div>

      {/* Insights Feed */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3>{t('dashboard.insightFeed')}</h3>
          <Button variant="ghost" size="sm" onClick={() => onNavigate?.('alerts')}>
            View all
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {mockInsights.map((insight) => (
            <InsightCard
              key={insight.id}
              insight={insight}
              onClick={() => onNavigate?.('chat')}
            />
          ))}
        </div>
      </div>

      {/* Full Report CTA */}
      <div className="card-elevated p-8 text-center gradient-primary text-white">
        <h3 className="mb-2 text-white">Need deeper insights?</h3>
        <p className="text-white/90 mb-4">
          Use our AI-powered chat assistant to analyze your data with natural language queries.
        </p>
        <Button 
          variant="secondary" 
          size="lg"
          onClick={() => onNavigate?.('chat')}
        >
          {t('dashboard.viewFullReport')}
        </Button>
      </div>
    </div>
  );
}
