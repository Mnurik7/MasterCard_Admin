import { ChatWidget } from '../components/chat/ChatWidget';

export function ChatPage() {
  return (
    <div className="h-[calc(100vh-4rem)]">
      <ChatWidget />
    </div>
  );
}
