import { FileText, Download, Clock, Star, MoreVertical, Plus, TrendingUp } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';
import { useTranslation } from '../lib/localization';
import { SpendChart } from '../components/charts/SpendChart';
import { formatRelativeTime } from '../lib/mockData';

interface Report {
  id: string;
  title: string;
  description: string;
  type: 'chart' | 'table' | 'dashboard';
  lastRun: string;
  schedule?: string;
  isFavorite: boolean;
  author: string;
}

export function ReportsPage() {
  const { t } = useTranslation();

  const reports: Report[] = [
    {
      id: 'RPT-001',
      title: 'Monthly Spend Analysis',
      description: 'Comprehensive breakdown of spending by category and region',
      type: 'dashboard',
      lastRun: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      schedule: 'Monthly',
      isFavorite: true,
      author: 'Sarah Johnson'
    },
    {
      id: 'RPT-002',
      title: 'Top Merchants Report',
      description: 'Analysis of top performing merchants by transaction volume',
      type: 'table',
      lastRun: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      schedule: 'Weekly',
      isFavorite: false,
      author: 'John Smith'
    },
    {
      id: 'RPT-003',
      title: 'Regional Performance',
      description: 'Geographic distribution of transactions and trends',
      type: 'chart',
      lastRun: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      isFavorite: true,
      author: 'Emily Davis'
    },
    {
      id: 'RPT-004',
      title: 'Declined Transactions',
      description: 'Analysis of declined transactions with reasons and patterns',
      type: 'table',
      lastRun: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
      schedule: 'Daily',
      isFavorite: false,
      author: 'Sarah Johnson'
    }
  ];

  const typeIcons = {
    chart: TrendingUp,
    table: FileText,
    dashboard: LayoutDashboard
  };

  const typeColors = {
    chart: 'bg-[var(--color-success-100)] text-[var(--color-success-700)]',
    table: 'bg-[var(--color-info-100)] text-[var(--color-info-700)]',
    dashboard: 'bg-[var(--color-primary-100)] text-[var(--color-primary-700)]'
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="mb-2">{t('nav.reports')}</h1>
          <p className="text-[var(--color-text-secondary)]">
            Saved reports, scheduled exports, and custom dashboards.
          </p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Create Report
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Total Reports</div>
          <div className="font-semibold text-2xl">{reports.length}</div>
        </div>
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Scheduled</div>
          <div className="font-semibold text-2xl">
            {reports.filter(r => r.schedule).length}
          </div>
        </div>
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Favorites</div>
          <div className="font-semibold text-2xl">
            {reports.filter(r => r.isFavorite).length}
          </div>
        </div>
        <div className="card-elevated p-5">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">Run Today</div>
          <div className="font-semibold text-2xl">12</div>
        </div>
      </div>

      {/* Featured Report Preview */}
      <div className="card-elevated p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="mb-1">Featured: Monthly Spend Trend</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">
              Last updated {formatRelativeTime(new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString())}
            </p>
          </div>
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="w-4 h-4" />
            Export
          </Button>
        </div>
        <SpendChart type="line" compact />
      </div>

      {/* Reports List */}
      <div>
        <h3 className="mb-4">All Reports</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {reports.map((report) => {
            const TypeIcon = typeIcons[report.type];
            return (
              <div key={report.id} className="card-elevated p-5 hover:shadow-lg transition-all group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${typeColors[report.type]}`}>
                      <TypeIcon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="truncate">{report.title}</h4>
                        {report.isFavorite && (
                          <Star className="w-4 h-4 fill-[var(--color-warning-500)] text-[var(--color-warning-500)] flex-shrink-0" />
                        )}
                      </div>
                      <p className="text-sm text-[var(--color-text-secondary)] line-clamp-2">
                        {report.description}
                      </p>
                    </div>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Run Now</DropdownMenuItem>
                      <DropdownMenuItem>
                        <Download className="w-4 h-4 mr-2" />
                        {t('button.export')}
                      </DropdownMenuItem>
                      <DropdownMenuItem>{t('button.edit')}</DropdownMenuItem>
                      <DropdownMenuItem className="text-[var(--color-error-600)]">
                        {t('button.delete')}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-4 text-[var(--color-text-tertiary)]">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{formatRelativeTime(report.lastRun)}</span>
                    </div>
                    {report.schedule && (
                      <Badge variant="secondary" className="text-xs">
                        {report.schedule}
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs text-[var(--color-text-tertiary)]">
                    by {report.author}
                  </span>
                </div>

                <div className="mt-4 pt-4 border-t border-[var(--color-border)] opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      View
                    </Button>
                    <Button size="sm" className="flex-1">
                      Run Report
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import { LayoutDashboard } from 'lucide-react';
