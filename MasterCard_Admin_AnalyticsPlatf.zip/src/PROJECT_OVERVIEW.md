# MasterCard Analytics Platform - Project Overview

## 🎯 Project Summary

**MasterCard Analytics Platform** is a comprehensive corporate analytics solution featuring an AI-powered chatbot (Gemini) for MasterCard employees and banking partners. This hackathon-ready project showcases modern web development, premium UX design, and multilingual support.

## ✨ Key Features

### 1. **AI-Powered Chat Analytics** 🤖
- Gemini-powered natural language query interface
- Voice input support with visual feedback
- SQL query display toggle for advanced users
- Suggested queries and quick actions
- Interactive data visualization in chat responses
- Compact widget + full-screen modes

### 2. **Comprehensive Dashboard** 📊
- Clean, minimal design with generous whitespace
- 4 mini KPI cards with sparklines and trends
- Real-time insight feed from AI
- Quick action buttons for common analytics tasks
- Pinned notes bar for important reminders
- Fully responsive (desktop/tablet/mobile)

### 3. **Smart Notes System** 📝
- Horizontal notes bar showing pinned notes
- Personal and shared notes
- Tag-based organization
- Link notes to transactions, reports, dashboards
- Real-time collaboration (simulated)
- Context menu: right-click → Add Note

### 4. **Transaction Explorer** 💳
- Advanced data table with sorting and filtering
- Search across all fields
- Row-level details modal
- Bulk actions and export
- Status badges (completed/pending/declined)
- Left-click context menu for quick actions

### 5. **Reports & Exports** 📈
- Saved query templates
- Scheduled report execution
- Interactive charts (bar, line, pie)
- Export to CSV/PDF
- Favorite reports
- Report sharing with team

### 6. **Alerts & Notifications** 🔔
- Custom alert creation (thresholds, conditions)
- Multi-channel delivery (email, push, in-app)
- Alert history and analytics
- Anomaly detection
- Real-time notifications

### 7. **Admin Panel** 🛡️
- User and role management (RBAC)
- Integration monitoring (Gemini, Firebase, Firestore)
- Audit log with timeline view
- Data quality metrics
- API usage tracking

### 8. **Multilingual Support** 🌍
- **English** (en) ✅
- **Russian** (ru) ✅
- **Kazakh** (kz) ✅
- Language switcher in top bar
- Instant UI updates on language change
- Localized date/number formats

## 🎨 Design Highlights

### Visual Style
- **Premium & Professional**: Corporate MasterCard branding
- **Minimal & Clean**: Generous spacing, focused content
- **Modern**: Smooth animations, hover states, micro-interactions
- **Accessible**: WCAG AA+ compliant, keyboard navigation

### Color Palette
```
Primary: Deep Blue (#234476)
Brand Gradient: Red → Orange → Yellow
Semantic: Green (success), Orange (warning), Red (error)
Neutrals: Gray scale from #1A1D23 to #F7F8FA
```

### Typography
- Font: Inter (system fallbacks)
- Scale: H1 (36px) → Body (15px) → Small (13px)
- Weights: 700 (headings), 600 (subheadings), 400 (body)

### Components
- **Cards**: Elevated with hover effects
- **Buttons**: 4 variants (primary, secondary, outline, ghost)
- **Inputs**: Consistent 40px height, focus states
- **Charts**: Recharts with custom styling
- **Icons**: Lucide React

## 📱 Responsive Design

### Desktop (1440px+)
- 12-column grid
- Collapsible sidebar (256px → 80px)
- Floating chat widget
- Max content width: 1600px

### Tablet (768px - 1024px)
- 8-column grid
- Adaptive navigation
- Touch-optimized interactions

### Mobile (< 768px)
- Single column layout
- Bottom navigation bar (5 items)
- Swipe gestures for quick actions
- Optimized forms and inputs

## 🏗️ Technical Architecture

### Tech Stack
```
Framework: React 18 + TypeScript
Styling: Tailwind CSS v4.0
UI Library: ShadCN UI
Charts: Recharts
Icons: Lucide React
State: React Hooks (useState, useEffect, Context)
Routing: Client-side navigation
```

### Project Structure
```
/
├── components/
│   ├── layout/       # TopBar, Sidebar, MobileNav
│   ├── dashboard/    # KPICard, NotesBar, InsightCard, QuickActions
│   ├── chat/         # ChatWidget (compact & full-screen)
│   ├── charts/       # SpendChart (bar & line)
│   ├── ui/           # ShadCN primitives
│   └── common/       # ToastProvider
├── pages/
│   ├── DashboardPage.tsx
│   ├── ChatPage.tsx
│   ├── TransactionsPage.tsx
│   ├── NotesPage.tsx
│   ├── ReportsPage.tsx
│   ├── AlertsPage.tsx
│   └── AdminPage.tsx
├── lib/
│   ├── localization.ts   # Multi-language support
│   ├── mockData.ts       # Sample data & formatters
│   └── utils.ts          # Helper functions
├── styles/
│   └── globals.css       # Design tokens & typography
└── App.tsx               # Main router & layout
```

### Key Files
- **`/styles/globals.css`**: Complete design system tokens
- **`/lib/localization.ts`**: Translation hook and strings
- **`/lib/mockData.ts`**: Realistic sample data
- **`/localization-samples.json`**: Translation reference
- **`/DESIGN_SYSTEM.md`**: Complete design documentation

## 🚀 Features Demo Flow

### Hackathon Presentation Path:

1. **Landing on Dashboard** (0:00 - 0:30)
   - Show clean, minimal design
   - Highlight pinned notes bar
   - Demonstrate KPI cards with trends
   - Click through quick actions

2. **AI Chat Demo** (0:30 - 1:30)
   - Open floating chat widget
   - Type natural language query: "Show spend by category for October"
   - Show SQL toggle
   - Demonstrate voice input
   - Add note from chat result
   - Create alert from insight

3. **Notes System** (1:30 - 2:00)
   - Navigate to Notes page
   - Show personal vs shared tabs
   - Create new note with tags
   - Pin/unpin notes
   - Show linked notes to transactions

4. **Transactions Explorer** (2:00 - 2:30)
   - Open transaction table
   - Search and filter
   - Click row for details modal
   - Right-click → Add note
   - Export selected rows

5. **Multilingual** (2:30 - 2:45)
   - Switch language to Russian
   - Show instant UI update
   - Switch to Kazakh
   - Back to English

6. **Admin Panel** (2:45 - 3:15)
   - Show user management
   - Display RBAC roles
   - Integration health monitoring
   - Audit log timeline

7. **Mobile Experience** (3:15 - 3:30)
   - Resize to mobile view
   - Show bottom navigation
   - Demonstrate compact layouts
   - Voice input on mobile

## 🎁 Wow Features (Differentiators)

### 1. **Inline Smart Notes**
- Bot automatically suggests "Add insight to notes" on anomaly detection
- One-click note creation with pre-filled content
- Linked directly to source data

### 2. **Context Menu Magic**
- Left-click any data point → instant actions menu
- Add note, export, create alert, deep dive
- Works on charts, tables, KPI cards

### 3. **Voice Analytics**
- Press and hold mic button
- Speak query in natural language
- See transcript + 3 interpreted query suggestions
- Confirm or edit before execution

### 4. **Real-Time Collaboration**
- Multiple users see note changes instantly (simulated)
- Presence indicators
- Collaborative editing

### 5. **Smart Query Suggestions**
- AI learns from your query history
- Suggests relevant follow-up questions
- Pre-built templates for common analyses

### 6. **Seamless Localization**
- Zero page reload on language switch
- Date/time formats auto-adapt
- Number formats (commas, decimals) localized

## 📊 Mock Data Included

### Transactions
- 100+ realistic transactions
- Categories: Travel, Shopping, Food, Entertainment, etc.
- Merchants: Amazon, Starbucks, Hilton, etc.
- Regions: North America, Europe, Asia, Middle East
- Date range: Last 90 days

### Analytics
- Monthly spend trends (10 months)
- Category breakdown with percentages
- Regional performance data
- Top merchants by volume

### Insights
- 4 pre-generated AI insights
- Types: anomaly, trend, alert, info
- Priority levels: high, medium, low

## 🔧 Development

### Running Locally
This is a Figma Make project - it runs automatically in the browser.

### Adding New Features
1. Create component in appropriate `/components` subfolder
2. Add translations to `/lib/localization.ts`
3. Update mock data in `/lib/mockData.ts` if needed
4. Import and use in page components

### Customization
- **Colors**: Update CSS variables in `/styles/globals.css`
- **Translations**: Add to `translations` object in `/lib/localization.ts`
- **Mock Data**: Modify functions in `/lib/mockData.ts`

## 🎯 Use Cases

### For MasterCard Employees
- **Analysts**: Query transaction data with natural language
- **Managers**: Monitor KPIs and trends
- **Executives**: Access high-level insights and reports

### For Banking Partners
- **Risk Teams**: Identify anomalies and fraud patterns
- **Operations**: Track transaction volumes and success rates
- **Compliance**: Audit trails and access logs

## 🏆 Hackathon Scoring Points

### Innovation (30%)
✅ AI-powered natural language queries
✅ Voice input for analytics
✅ Smart context-aware notes
✅ Real-time collaboration

### Design (25%)
✅ Premium corporate aesthetic
✅ Fully responsive (3 breakpoints)
✅ Accessibility compliant (AA+)
✅ Smooth animations and micro-interactions

### Functionality (25%)
✅ 8 complete pages/features
✅ Multi-language support (3 languages)
✅ Interactive data visualizations
✅ Admin panel with monitoring

### Technical Excellence (20%)
✅ Clean, modular code architecture
✅ TypeScript for type safety
✅ Reusable component library
✅ Comprehensive documentation

## 📝 Future Roadmap

### Phase 2 Features
- [ ] Real backend integration (Supabase)
- [ ] Live data from Gemini API
- [ ] Advanced query builder (drag & drop)
- [ ] Custom dashboard builder
- [ ] Mobile app (React Native)

### Phase 3 Enhancements
- [ ] AI-powered report generation
- [ ] Predictive analytics
- [ ] Integration with BI tools (Tableau, PowerBI)
- [ ] Advanced visualization (D3.js)
- [ ] Video call integration for collaboration

## 🤝 Contributing

This is a hackathon demo project. For production use:
1. Replace mock data with real API calls
2. Implement proper authentication (Firebase/Auth0)
3. Set up backend (Supabase recommended)
4. Add proper error handling and loading states
5. Implement data persistence
6. Add comprehensive testing

## 📄 License

This project is a demonstration for hackathon purposes.
MasterCard branding used for educational purposes only.

## 📧 Contact

**Project Team**: MasterCard Analytics Innovation Lab
**Demo Date**: November 2025
**Version**: 1.0.0 (Hackathon Ready)

---

## 🎬 Quick Start Guide

### For Judges/Reviewers:
1. **Start**: App loads on Dashboard
2. **Explore**: Use sidebar to navigate pages
3. **Chat**: Click floating button (bottom right) or go to Chat page
4. **Mobile**: Resize window < 768px to see mobile view
5. **Language**: Click globe icon (top right) to switch languages

### Key Interactions:
- Click any KPI card → view details
- Right-click transaction → quick menu
- Pin notes → appears in dashboard bar
- Voice icon in chat → speak query
- "Show SQL" in chat → see query

### Best Features to Demo:
1. Voice input in chat (**wow factor**)
2. Language switcher (**instant UI change**)
3. Notes bar on dashboard (**convenience**)
4. Admin panel (**comprehensive**)
5. Mobile bottom nav (**UX excellence**)

---

**Built with ❤️ for the MasterCard Hackathon 2025**
