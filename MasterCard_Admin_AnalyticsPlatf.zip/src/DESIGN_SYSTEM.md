# MasterCard Analytics Platform - Design System Documentation

## Overview
This document describes the design system for the MasterCard Analytics Platform, a corporate analytics chatbot for MasterCard employees and banking partners.

## Design Philosophy
- **Professional & Trustworthy**: Corporate design with emphasis on clarity and reliability
- **Minimal & Clean**: Generous whitespace, focused content, easy data perception
- **Premium Feel**: High-quality components with subtle animations and transitions
- **Accessible**: AA+ contrast ratios, keyboard navigation, screen reader support

## Color System

### Primary Colors (Corporate Deep Blue)
```
--color-primary-900: #0A1628  // Darkest
--color-primary-800: #132442
--color-primary-700: #1A345C
--color-primary-600: #234476  // Main brand color
--color-primary-500: #2C5490
--color-primary-400: #4A6FA8
--color-primary-300: #6B8BC0
--color-primary-200: #9DB3D9
--color-primary-100: #D0DCF0  // Lightest
```

### Neutral Grays
```
--color-neutral-900: #1A1D23  // Darkest text
--color-neutral-800: #2C3038
--color-neutral-700: #3E444E
--color-neutral-600: #565D6B
--color-neutral-500: #707784
--color-neutral-400: #9299A6
--color-neutral-300: #B5BBC5
--color-neutral-200: #D8DCE3
--color-neutral-100: #EEF0F4
--color-neutral-50: #F7F8FA   // Background
```

### MasterCard Brand Colors
```
--color-brand-orange: #FF5F00
--color-brand-red: #EB001B
--color-brand-yellow: #F79E1B
```
**Usage**: Gradients, accent elements, CTAs. Apply as `gradient-brand` class.

### Semantic Colors
```
Success (Green):
  --color-success-600: #059669 (dark)
  --color-success-500: #10B981 (main)
  --color-success-100: #D1FAE5 (light bg)

Warning (Orange):
  --color-warning-600: #D97706
  --color-warning-500: #F59E0B
  --color-warning-100: #FEF3C7

Error (Red):
  --color-error-600: #DC2626
  --color-error-500: #EF4444
  --color-error-100: #FEE2E2

Info (Blue):
  --color-info-600: #2563EB
  --color-info-500: #3B82F6
  --color-info-100: #DBEAFE
```

## Typography

### Font Stack
```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
```

### Type Scale
```
H1: 36px / 2.25rem - font-weight: 700 - letter-spacing: -0.02em
H2: 30px / 1.875rem - font-weight: 700 - letter-spacing: -0.01em
H3: 24px / 1.5rem - font-weight: 600 - letter-spacing: -0.01em
H4: 20px / 1.25rem - font-weight: 600
H5: 18px / 1.125rem - font-weight: 600
Body: 15px / 0.9375rem - font-weight: 400
Small: 13px / 0.8125rem - font-weight: 400
XS: 12px / 0.75rem - font-weight: 400
```

**Important**: Do NOT override font sizes, weights, or line-heights in components unless specifically requested. The system handles typography automatically.

## Spacing System (8px base)
```
--spacing-xs: 4px
--spacing-sm: 8px
--spacing-md: 16px
--spacing-lg: 24px
--spacing-xl: 32px
--spacing-2xl: 48px
--spacing-3xl: 64px
```

## Border Radius
```
--radius-sm: 6px   // Small elements (badges, tags)
--radius-md: 8px   // Buttons, inputs
--radius-lg: 12px  // Cards, panels
--radius-xl: 16px  // Large containers
--radius-full: 9999px // Pills, avatars
```

## Shadows
```
--shadow-sm: Subtle hover states
--shadow-md: Card default elevation
--shadow-lg: Card hover, modals
--shadow-xl: Floating elements, dropdowns
```

## Grid System

### Desktop (1440px+)
- 12-column grid
- Max content width: 1600px
- Gutter: 24px

### Tablet (768px - 1024px)
- 8-column grid
- Adaptive margins
- Gutter: 16px

### Mobile (< 768px)
- Single column / 4-column grid
- Full-width with padding
- Bottom navigation bar

## Component Library

### Cards
**KPICard**: Mini cards for metrics with optional sparklines and trends
- Compact version: p-4
- Standard version: p-5
- Hover effect: scale(1.02) + shadow-lg

**InsightCard**: Display AI-generated insights with type-based colors
- Icon badges for type (anomaly, trend, alert, info)
- Priority indicators (high/medium/low)
- Clickable with hover states

### Navigation
**TopBar**: Fixed header with logo, search, language switcher, notifications
- Height: 64px (4rem)
- Sticky positioning
- z-index: 40

**Sidebar**: Collapsible navigation
- Desktop: 256px width (collapsed: 80px)
- Icon + label layout
- Active state: primary-100 background

**MobileNav**: Bottom navigation bar for mobile
- Fixed bottom positioning
- 5 main items
- Icon + label
- z-index: 50

### Forms & Inputs
**Input**: Standard text input
- Height: 40px
- Border: 1px solid border color
- Focus: 2px outline primary-500

**Select**: Dropdown selector using ShadCN
**Textarea**: Multi-line text input
**Checkbox/Radio**: Standard form controls

### Buttons
```
Primary: gradient-brand or primary-600 background
Secondary: neutral-200 background
Outline: border with transparent background
Ghost: transparent, hover background
```

**Sizes**:
- sm: h-8 px-3
- default: h-10 px-4
- lg: h-12 px-6
- icon: square dimensions

### Chat Widget
**Compact Mode**: 384px × 500px floating widget
**Full Mode**: Full-screen chat interface
**Features**:
- Voice input with animation
- SQL toggle
- Suggested queries
- Quick actions (Export, Add Note, Alert)

### Notes System
**NotesBar**: Horizontal bar at top of dashboard showing pinned notes
**NoteCard**: Individual note with tags, author, timestamp
**Features**:
- Pin/unpin
- Personal vs shared
- Tag filtering
- Link to transactions/reports

### Data Visualization
**SpendChart**: Bar and line charts using Recharts
- Responsive containers
- Custom tooltips
- Color-coded by data type

## Responsive Breakpoints
```
Mobile: < 768px
Tablet: 768px - 1024px
Desktop: 1024px - 1440px
Large Desktop: > 1440px
```

## Accessibility

### Color Contrast
- All text meets WCAG AA standards
- Primary text: #1A1D23 on #FFFFFF (ratio 16:1)
- Secondary text: #565D6B on #FFFFFF (ratio 8:1)

### Keyboard Navigation
- Tab order follows visual hierarchy
- Focus indicators: 2px outline
- Esc closes modals/dropdowns
- Enter submits forms

### Screen Readers
- Semantic HTML
- ARIA labels on interactive elements
- Alt text for images
- Role attributes where needed

## Animations & Transitions
```
--transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1)
--transition-base: 250ms cubic-bezier(0.4, 0, 0.2, 1)
--transition-slow: 350ms cubic-bezier(0.4, 0, 0.2, 1)
```

**Common animations**:
- Hover: opacity, scale, shadow changes
- Loading: skeleton loaders
- Micro-interactions: button press, card lift

## Localization

### Supported Languages
1. English (en)
2. Russian (ru)
3. Kazakh (kz)

### Implementation
```typescript
import { useTranslation } from '../lib/localization';

const { t, language, changeLanguage } = useTranslation();
const text = t('dashboard.title'); // Returns translated string
```

### Coverage
- Navigation: 100%
- Dashboard: 100%
- Chat: 100%
- Forms & Buttons: 100%

See `/localization-samples.json` for complete translation reference.

## Dark Mode Support

Toggle available via settings. Uses `[data-theme="dark"]` attribute on root element.

**Dark mode colors**:
```
Background: #0A0E14
Surface: #1A1D23
Text primary: #F7F8FA
```

## Best Practices

### DO:
✅ Use design tokens (CSS variables) instead of hardcoded colors
✅ Apply auto-layout and proper spacing
✅ Use semantic HTML
✅ Follow mobile-first responsive approach
✅ Test keyboard navigation
✅ Maintain consistent spacing (8px grid)

### DON'T:
❌ Override typography styles (font-size, font-weight, line-height) without reason
❌ Use arbitrary colors outside the design system
❌ Create inconsistent hover states
❌ Ignore mobile breakpoints
❌ Skip accessibility attributes

## Developer Handoff

### Tech Stack
- React 18+ with TypeScript
- Tailwind CSS v4.0
- ShadCN UI components
- Recharts for data visualization
- Lucide React for icons

### CSS Architecture
- CSS variables in `/styles/globals.css`
- Tailwind utility classes
- Component-scoped styles when needed

### Component Structure
```
/components
  /layout       - Navigation, TopBar, Sidebar
  /dashboard    - KPI cards, insights, quick actions
  /chat         - Chat widget and interface
  /notes        - Notes system
  /charts       - Data visualization
  /ui           - ShadCN primitives
  /common       - Shared utilities
```

### State Management
- React useState/useEffect for local state
- Context for language switching
- Mock data in `/lib/mockData.ts`

## Future Enhancements

### Planned Features
- [ ] Real-time collaboration on notes
- [ ] Advanced query builder (drag & drop)
- [ ] Scheduled reports
- [ ] Mobile push notifications
- [ ] Voice commands
- [ ] Dark mode auto-switch
- [ ] Custom dashboard builder
- [ ] Export to multiple formats (PDF, Excel)
- [ ] Integration with external BI tools

### Performance Optimizations
- Lazy loading for charts
- Virtual scrolling for large tables
- Image optimization
- Code splitting by route

## Contact & Support

For questions about the design system:
- Design Lead: design@mastercard.com
- Development: dev@mastercard.com
- Documentation: Update this file when adding new components

---

**Last Updated**: November 2025
**Version**: 1.0.0
**Status**: Production Ready
