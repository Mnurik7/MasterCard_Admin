import { useState, useRef, useEffect } from 'react';
import { Send, Mic, X, Maximize2, Code, Download, StickyNote, Bell } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { useTranslation } from '../../lib/localization';
import { mockSuggestedQueries, generateMockChatResponse } from '../../lib/mockData';
import { Badge } from '../ui/badge';

interface Message {
  id: string;
  type: 'user' | 'bot' | 'system';
  content: string;
  timestamp: Date;
  data?: any;
  sql?: string;
}

interface ChatWidgetProps {
  compact?: boolean;
  onExpand?: () => void;
  onClose?: () => void;
}

export function ChatWidget({ compact = false, onExpand, onClose }: ChatWidgetProps) {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: t('chat.placeholder'),
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [showSQL, setShowSQL] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Simulate bot response
    setTimeout(() => {
      const response = generateMockChatResponse(input);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: `Here's the analysis for: "${input}"`,
        timestamp: new Date(),
        data: response.data,
        sql: response.sql,
      };
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const handleVoiceInput = () => {
    setIsListening(true);
    // Simulate voice input
    setTimeout(() => {
      setIsListening(false);
      setInput('Show spend by category for October');
    }, 2000);
  };

  const handleSuggestedQuery = (query: string) => {
    setInput(query);
    setTimeout(() => handleSend(), 100);
  };

  if (compact) {
    return (
      <div className="w-96 h-[500px] card-elevated flex flex-col">
        {/* Compact Header */}
        <div className="p-4 border-b border-[var(--color-border)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center">
              <span className="text-white text-sm font-semibold">AI</span>
            </div>
            <div>
              <div className="font-semibold text-sm">{t('chat.title')}</div>
              <div className="text-xs text-[var(--color-text-tertiary)]">Powered by Gemini</div>
            </div>
          </div>
          <div className="flex gap-1">
            {onExpand && (
              <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onExpand}>
                <Maximize2 className="w-4 h-4" />
              </Button>
            )}
            {onClose && (
              <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((message) => (
            <div key={message.id}>
              <ChatMessage message={message} showSQL={showSQL} compact />
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-[var(--color-border)]">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={t('chat.placeholder')}
              disabled={isListening}
              className="flex-1"
            />
            <Button
              size="icon"
              variant={isListening ? 'default' : 'ghost'}
              onClick={handleVoiceInput}
              className={isListening ? 'bg-[var(--color-error-500)] hover:bg-[var(--color-error-600)]' : ''}
            >
              <Mic className="w-4 h-4" />
            </Button>
            <Button size="icon" onClick={handleSend}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
          {isListening && (
            <div className="text-xs text-[var(--color-text-tertiary)] mt-2 flex items-center gap-2">
              <div className="w-2 h-2 bg-[var(--color-error-500)] rounded-full animate-pulse" />
              {t('chat.listening')}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Full screen version
  return (
    <div className="h-full flex flex-col bg-[var(--color-background)]">
      {/* Header */}
      <div className="p-6 border-b border-[var(--color-border)] bg-[var(--color-surface)]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl gradient-brand flex items-center justify-center">
              <span className="text-white font-semibold">AI</span>
            </div>
            <div>
              <h2 className="font-semibold">{t('chat.title')}</h2>
              <p className="text-sm text-[var(--color-text-tertiary)]">Powered by Gemini AI</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowSQL(!showSQL)}
            className="gap-2"
          >
            <Code className="w-4 h-4" />
            {showSQL ? 'Hide SQL' : 'Show SQL'}
          </Button>
        </div>

        {/* Suggested Queries */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {mockSuggestedQueries.slice(0, 4).map((query, idx) => (
            <Button
              key={idx}
              variant="outline"
              size="sm"
              onClick={() => handleSuggestedQuery(query)}
              className="whitespace-nowrap text-xs"
            >
              {query}
            </Button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div key={message.id}>
            <ChatMessage message={message} showSQL={showSQL} />
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-6 border-t border-[var(--color-border)] bg-[var(--color-surface)]">
        <div className="flex gap-3 mb-3">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={t('chat.placeholder')}
            disabled={isListening}
            className="flex-1 h-12"
          />
          <Button
            size="icon"
            variant={isListening ? 'default' : 'outline'}
            onClick={handleVoiceInput}
            className={`h-12 w-12 ${isListening ? 'bg-[var(--color-error-500)] hover:bg-[var(--color-error-600)]' : ''}`}
          >
            <Mic className="w-5 h-5" />
          </Button>
          <Button size="icon" onClick={handleSend} className="h-12 w-12">
            <Send className="w-5 h-5" />
          </Button>
        </div>
        {isListening && (
          <div className="text-sm text-[var(--color-text-tertiary)] flex items-center gap-2">
            <div className="w-2 h-2 bg-[var(--color-error-500)] rounded-full animate-pulse" />
            {t('chat.listening')}
          </div>
        )}
      </div>
    </div>
  );
}

// Chat Message Component
function ChatMessage({ message, showSQL, compact }: { message: Message; showSQL: boolean; compact?: boolean }) {
  const isBot = message.type === 'bot';

  return (
    <div className={`flex gap-3 ${!isBot && 'flex-row-reverse'}`}>
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
        isBot ? 'gradient-brand' : 'bg-[var(--color-neutral-200)]'
      }`}>
        <span className={`text-xs font-semibold ${isBot ? 'text-white' : 'text-[var(--color-text-primary)]'}`}>
          {isBot ? 'AI' : 'You'}
        </span>
      </div>

      <div className={`flex-1 ${!compact && 'max-w-3xl'}`}>
        <div className={`rounded-lg p-3 ${
          isBot 
            ? 'bg-[var(--color-surface)] border border-[var(--color-border)]' 
            : 'bg-[var(--color-primary-100)] text-[var(--color-primary-900)]'
        }`}>
          <p className="text-sm">{message.content}</p>

          {message.sql && showSQL && (
            <div className="mt-3 p-3 bg-[var(--color-neutral-900)] text-[var(--color-success-400)] rounded text-xs font-mono overflow-x-auto">
              {message.sql}
            </div>
          )}

          {message.data && (
            <div className="mt-3">
              <DataVisualization data={message.data} compact={compact} />
            </div>
          )}
        </div>

        {isBot && message.data && (
          <div className="flex gap-2 mt-2">
            <Button size="sm" variant="ghost" className="h-7 text-xs gap-1">
              <Download className="w-3 h-3" />
              Export
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs gap-1">
              <StickyNote className="w-3 h-3" />
              Add Note
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs gap-1">
              <Bell className="w-3 h-3" />
              Create Alert
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

// Simple data visualization
function DataVisualization({ data, compact }: { data: any; compact?: boolean }) {
  if (!data || !Array.isArray(data)) return null;

  return (
    <div className="space-y-2">
      {data.slice(0, compact ? 3 : 5).map((item: any, idx: number) => (
        <div key={idx} className="flex items-center justify-between text-xs">
          <span className="text-[var(--color-text-secondary)]">
            {item.category || item.merchant || item.region || item.month}
          </span>
          <div className="flex items-center gap-2">
            {item.amount && (
              <span className="font-semibold">
                ${(item.amount / 1000).toFixed(0)}K
              </span>
            )}
            {item.spend && (
              <span className="font-semibold">
                ${(item.spend / 1000).toFixed(0)}K
              </span>
            )}
            {item.percentage && (
              <Badge variant="secondary" className="text-xs">
                {item.percentage}%
              </Badge>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
