import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { mockSpendByCategory, mockSpendTrend } from '../../lib/mockData';

interface SpendChartProps {
  type?: 'bar' | 'line';
  data?: any[];
  compact?: boolean;
}

export function SpendChart({ type = 'bar', data, compact = false }: SpendChartProps) {
  const chartData = data || (type === 'line' ? mockSpendTrend : mockSpendByCategory);

  const colors = [
    'var(--color-primary-600)',
    'var(--color-primary-500)',
    'var(--color-primary-400)',
    'var(--color-info-500)',
    'var(--color-success-500)',
    'var(--color-warning-500)',
    'var(--color-brand-orange)',
    'var(--color-neutral-500)',
    'var(--color-neutral-400)',
  ];

  if (type === 'line') {
    return (
      <ResponsiveContainer width="100%" height={compact ? 200 : 300}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
          <XAxis 
            dataKey="month" 
            stroke="var(--color-text-tertiary)"
            style={{ fontSize: '12px' }}
          />
          <YAxis 
            stroke="var(--color-text-tertiary)"
            style={{ fontSize: '12px' }}
            tickFormatter={(value) => `$${(value / 1000000).toFixed(1)}M`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'var(--color-surface)',
              border: '1px solid var(--color-border)',
              borderRadius: '8px',
              fontSize: '12px'
            }}
            formatter={(value: any) => [`$${(value / 1000000).toFixed(2)}M`, 'Spend']}
          />
          <Line 
            type="monotone" 
            dataKey="spend" 
            stroke="var(--color-primary-600)" 
            strokeWidth={2}
            dot={{ fill: 'var(--color-primary-600)', r: 4 }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={compact ? 200 : 300}>
      <BarChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
        <XAxis 
          dataKey="category" 
          stroke="var(--color-text-tertiary)"
          style={{ fontSize: '11px' }}
          angle={-45}
          textAnchor="end"
          height={80}
        />
        <YAxis 
          stroke="var(--color-text-tertiary)"
          style={{ fontSize: '12px' }}
          tickFormatter={(value) => `$${(value / 1000000).toFixed(1)}M`}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: '8px',
            fontSize: '12px'
          }}
          formatter={(value: any) => [`$${(value / 1000000).toFixed(2)}M`, 'Amount']}
        />
        <Bar dataKey="amount" radius={[8, 8, 0, 0]}>
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
