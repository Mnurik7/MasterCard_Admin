import { CheckCircle, MessageSquare, StickyNote, TrendingUp, Globe, Sparkles } from 'lucide-react';
import { Button } from '../ui/button';

interface WelcomeScreenProps {
  onComplete: () => void;
}

export function WelcomeScreen({ onComplete }: WelcomeScreenProps) {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[var(--color-primary-700)] to-[var(--color-primary-900)] z-50 flex items-center justify-center p-6">
      <div className="max-w-4xl w-full">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-16 h-16 rounded-2xl gradient-brand flex items-center justify-center shadow-2xl">
              <svg viewBox="0 0 24 24" fill="white" className="w-10 h-10">
                <circle cx="9" cy="12" r="7" opacity="0.9" />
                <circle cx="15" cy="12" r="7" opacity="0.9" />
              </svg>
            </div>
          </div>
          <h1 className="text-white mb-3">Welcome to MasterCard Analytics</h1>
          <p className="text-white/80 text-lg">
            Your AI-powered analytics platform for transaction insights
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <FeatureCard
            icon={<MessageSquare className="w-6 h-6" />}
            title="AI Chat Analytics"
            description="Ask questions in natural language. Get instant insights powered by Gemini AI."
          />
          <FeatureCard
            icon={<StickyNote className="w-6 h-6" />}
            title="Smart Notes"
            description="Capture insights, collaborate with team, link to transactions and reports."
          />
          <FeatureCard
            icon={<TrendingUp className="w-6 h-6" />}
            title="Real-time Insights"
            description="Monitor KPIs, detect anomalies, and get proactive alerts."
          />
          <FeatureCard
            icon={<Globe className="w-6 h-6" />}
            title="Multilingual"
            description="Switch between English, Russian, and Kazakh instantly."
          />
          <FeatureCard
            icon={<Sparkles className="w-6 h-6" />}
            title="Voice Commands"
            description="Speak your queries with voice input for hands-free analytics."
          />
          <FeatureCard
            icon={<CheckCircle className="w-6 h-6" />}
            title="Secure & Compliant"
            description="Enterprise-grade security with role-based access control."
          />
        </div>

        {/* Quick Tips */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-8">
          <h3 className="text-white mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Quick Tips to Get Started
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Tip number="1" text="Click the chat button to ask analytics questions" />
            <Tip number="2" text="Pin important notes to see them on dashboard" />
            <Tip number="3" text="Right-click any data point for quick actions" />
            <Tip number="4" text="Switch languages using the globe icon" />
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button
            size="lg"
            onClick={onComplete}
            className="bg-white text-[var(--color-primary-700)] hover:bg-white/90 h-14 px-8 text-lg font-semibold shadow-2xl"
          >
            Get Started
          </Button>
          <p className="text-white/60 text-sm mt-4">
            Press Enter or click to continue
          </p>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-5 border border-white/20 hover:bg-white/20 transition-all">
      <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center text-white mb-4">
        {icon}
      </div>
      <h4 className="text-white mb-2">{title}</h4>
      <p className="text-white/70 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function Tip({ number, text }: { number: string; text: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
        {number}
      </div>
      <p className="text-white/90 text-sm">{text}</p>
    </div>
  );
}
