import { Plus, Pin, X, Edit2 } from 'lucide-react';
import { Button } from '../ui/button';
import { useTranslation } from '../../lib/localization';
import { useState } from 'react';
import { mockNotes, formatRelativeTime } from '../../lib/mockData';
import { Badge } from '../ui/badge';

interface NotesBarProps {
  onAddNote?: () => void;
}

export function NotesBar({ onAddNote }: NotesBarProps) {
  const { t } = useTranslation();
  const [notes, setNotes] = useState(mockNotes.filter(n => n.isPinned).slice(0, 3));

  return (
    <div className="bg-gradient-to-r from-[var(--color-primary-50)] to-[var(--color-neutral-50)] border-b border-[var(--color-border)] px-6 py-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Pin className="w-4 h-4 text-[var(--color-primary-600)]" />
          <span className="font-semibold text-sm text-[var(--color-text-primary)]">
            {t('note.pinned')}
          </span>
        </div>
        <Button 
          size="sm" 
          variant="ghost" 
          onClick={onAddNote}
          className="h-7 gap-1.5 text-[var(--color-primary-600)] hover:bg-[var(--color-primary-100)]"
        >
          <Plus className="w-3.5 h-3.5" />
          {t('note.add')}
        </Button>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-1">
        {notes.length === 0 ? (
          <div className="text-sm text-[var(--color-text-tertiary)] py-2">
            No pinned notes. Click "+ Add Note" to create one.
          </div>
        ) : (
          notes.map((note) => (
            <div
              key={note.id}
              className="min-w-[280px] max-w-[320px] bg-white rounded-lg p-3 border border-[var(--color-border)] hover:shadow-md transition-shadow group"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="text-sm text-[var(--color-text-primary)] line-clamp-2 mb-1">
                    {note.content}
                  </div>
                  <div className="text-xs text-[var(--color-text-tertiary)]">
                    {note.author} • {formatRelativeTime(note.timestamp)}
                  </div>
                </div>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 ml-2">
                  <Button size="icon" variant="ghost" className="h-6 w-6">
                    <Edit2 className="w-3 h-3" />
                  </Button>
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    className="h-6 w-6"
                    onClick={() => setNotes(notes.filter(n => n.id !== note.id))}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              {note.tags.length > 0 && (
                <div className="flex gap-1 flex-wrap">
                  {note.tags.slice(0, 3).map((tag) => (
                    <Badge 
                      key={tag} 
                      variant="secondary"
                      className="text-xs px-2 py-0 h-5"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
