import { AlertTriangle, TrendingUp, Bell, Info, ArrowRight } from 'lucide-react';
import { Insight } from '../../lib/mockData';
import { Badge } from '../ui/badge';
import { cn } from '../../lib/utils';
import { formatRelativeTime } from '../../lib/mockData';

interface InsightCardProps {
  insight: Insight;
  onClick?: () => void;
}

export function InsightCard({ insight, onClick }: InsightCardProps) {
  const iconMap = {
    anomaly: AlertTriangle,
    trend: TrendingUp,
    alert: Bell,
    info: Info,
  };

  const colorMap = {
    anomaly: {
      bg: 'bg-[var(--color-error-100)]',
      text: 'text-[var(--color-error-600)]',
      border: 'border-[var(--color-error-200)]'
    },
    trend: {
      bg: 'bg-[var(--color-success-100)]',
      text: 'text-[var(--color-success-600)]',
      border: 'border-[var(--color-success-200)]'
    },
    alert: {
      bg: 'bg-[var(--color-warning-100)]',
      text: 'text-[var(--color-warning-600)]',
      border: 'border-[var(--color-warning-200)]'
    },
    info: {
      bg: 'bg-[var(--color-info-100)]',
      text: 'text-[var(--color-info-600)]',
      border: 'border-[var(--color-info-200)]'
    },
  };

  const Icon = iconMap[insight.type];
  const colors = colorMap[insight.type];

  const priorityColors = {
    high: 'bg-[var(--color-error-500)]',
    medium: 'bg-[var(--color-warning-500)]',
    low: 'bg-[var(--color-info-500)]',
  };

  return (
    <div
      onClick={onClick}
      className={cn(
        'card-elevated p-4 hover:shadow-lg transition-all',
        onClick && 'cursor-pointer hover:scale-[1.01]'
      )}
    >
      <div className="flex items-start gap-3">
        <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0', colors.bg, colors.text)}>
          <Icon className="w-5 h-5" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h4 className="font-semibold text-sm text-[var(--color-text-primary)]">
              {insight.title}
            </h4>
            <div className={cn('w-2 h-2 rounded-full flex-shrink-0 mt-1.5', priorityColors[insight.priority])} />
          </div>

          <p className="text-sm text-[var(--color-text-secondary)] mb-3 line-clamp-2">
            {insight.description}
          </p>

          <div className="flex items-center justify-between">
            <span className="text-xs text-[var(--color-text-tertiary)]">
              {formatRelativeTime(insight.timestamp)}
            </span>
            {onClick && (
              <ArrowRight className="w-4 h-4 text-[var(--color-primary-500)]" />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
