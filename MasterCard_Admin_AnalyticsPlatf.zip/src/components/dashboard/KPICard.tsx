import { TrendingUp, TrendingDown, ArrowRight } from 'lucide-react';
import { cn } from '../../lib/utils';

interface KPICardProps {
  title: string;
  value: string | number;
  change?: number;
  subtitle?: string;
  icon?: React.ReactNode;
  trend?: number[];
  onClick?: () => void;
  compact?: boolean;
}

export function KPICard({ 
  title, 
  value, 
  change, 
  subtitle, 
  icon, 
  trend,
  onClick,
  compact = false 
}: KPICardProps) {
  const isPositive = change !== undefined && change >= 0;
  
  return (
    <div
      onClick={onClick}
      className={cn(
        'card-elevated p-5 transition-all',
        onClick && 'cursor-pointer hover:shadow-lg hover:scale-[1.02]',
        compact && 'p-4'
      )}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="text-sm text-[var(--color-text-tertiary)] mb-1">{title}</div>
          <div className={cn('font-semibold text-[var(--color-text-primary)]', compact ? 'text-2xl' : 'text-3xl')}>
            {value}
          </div>
          {subtitle && (
            <div className="text-xs text-[var(--color-text-tertiary)] mt-1">{subtitle}</div>
          )}
        </div>
        {icon && (
          <div className="w-10 h-10 rounded-lg bg-[var(--color-primary-100)] flex items-center justify-center text-[var(--color-primary-600)]">
            {icon}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between">
        {change !== undefined && (
          <div className={cn(
            'flex items-center gap-1 text-sm font-medium',
            isPositive ? 'text-[var(--color-success-600)]' : 'text-[var(--color-error-600)]'
          )}>
            {isPositive ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            <span>{isPositive ? '+' : ''}{change.toFixed(1)}%</span>
          </div>
        )}

        {trend && trend.length > 0 && (
          <div className="flex-1 ml-3">
            <MiniSparkline data={trend} positive={isPositive} />
          </div>
        )}

        {onClick && (
          <ArrowRight className="w-4 h-4 text-[var(--color-text-tertiary)] ml-auto" />
        )}
      </div>
    </div>
  );
}

// Mini sparkline component
function MiniSparkline({ data, positive }: { data: number[]; positive?: boolean }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min;
  
  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * 100;
    const y = 100 - ((value - min) / range) * 100;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg viewBox="0 0 100 20" className="w-full h-6" preserveAspectRatio="none">
      <polyline
        points={points}
        fill="none"
        stroke={positive ? 'var(--color-success-500)' : 'var(--color-error-500)'}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
