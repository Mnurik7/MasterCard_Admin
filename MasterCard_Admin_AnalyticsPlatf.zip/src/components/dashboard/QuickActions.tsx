import { PieChart, Building2, MapPin, FileText, Clock } from 'lucide-react';
import { Button } from '../ui/button';
import { useTranslation } from '../../lib/localization';

interface QuickActionsProps {
  onAction?: (action: string) => void;
}

export function QuickActions({ onAction }: QuickActionsProps) {
  const { t } = useTranslation();

  const actions = [
    { id: 'categories', icon: PieChart, label: t('dashboard.categories'), color: 'from-blue-500 to-blue-600' },
    { id: 'merchants', icon: Building2, label: t('dashboard.merchants'), color: 'from-purple-500 to-purple-600' },
    { id: 'geography', icon: MapPin, label: t('dashboard.geography'), color: 'from-green-500 to-green-600' },
    { id: 'reports', icon: FileText, label: t('nav.reports'), color: 'from-orange-500 to-orange-600' },
    { id: 'recent', icon: Clock, label: t('dashboard.recentQueries'), color: 'from-pink-500 to-pink-600' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      {actions.map((action) => {
        const Icon = action.icon;
        return (
          <button
            key={action.id}
            onClick={() => onAction?.(action.id)}
            className="flex flex-col items-center gap-3 p-4 rounded-xl bg-[var(--color-surface)] border border-[var(--color-border)] hover:shadow-md hover:scale-105 transition-all group"
          >
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
            <span className="text-sm font-medium text-[var(--color-text-primary)] text-center">
              {action.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
