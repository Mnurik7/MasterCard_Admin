import { 
  LayoutDashboard, 
  MessageSquare, 
  Receipt, 
  FileText, 
  StickyNote, 
  Bell, 
  Settings, 
  Shield,
  ChevronLeft
} from 'lucide-react';
import { Button } from '../ui/button';
import { useTranslation } from '../../lib/localization';
import { cn } from '../../lib/utils';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}

export function Sidebar({ currentPage, onNavigate, collapsed = false, onToggleCollapse }: SidebarProps) {
  const { t } = useTranslation();

  const navItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: t('nav.dashboard') },
    { id: 'chat', icon: MessageSquare, label: t('nav.chat') },
    { id: 'transactions', icon: Receipt, label: t('nav.transactions') },
    { id: 'reports', icon: FileText, label: t('nav.reports') },
    { id: 'notes', icon: StickyNote, label: t('nav.notes') },
    { id: 'alerts', icon: Bell, label: t('nav.alerts') },
  ];

  const bottomItems = [
    { id: 'admin', icon: Shield, label: t('nav.admin') },
    { id: 'settings', icon: Settings, label: t('nav.settings') },
  ];

  return (
    <div
      className={cn(
        'h-[calc(100vh-4rem)] border-r border-[var(--color-border)] bg-[var(--color-surface)] flex flex-col transition-all duration-300',
        collapsed ? 'w-20' : 'w-64'
      )}
    >
      {/* Main Navigation */}
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => onNavigate(item.id)}
              className={cn(
                'w-full justify-start gap-3 h-11 px-3',
                isActive && 'bg-[var(--color-primary-100)] text-[var(--color-primary-700)] hover:bg-[var(--color-primary-100)]',
                collapsed && 'justify-center px-2'
              )}
            >
              <Icon className={cn('w-5 h-5', collapsed ? 'mr-0' : 'mr-0')} />
              {!collapsed && <span>{item.label}</span>}
            </Button>
          );
        })}
      </nav>

      {/* Bottom Navigation */}
      <div className="p-3 space-y-1 border-t border-[var(--color-border)]">
        {bottomItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => onNavigate(item.id)}
              className={cn(
                'w-full justify-start gap-3 h-11 px-3',
                isActive && 'bg-[var(--color-primary-100)] text-[var(--color-primary-700)]',
                collapsed && 'justify-center px-2'
              )}
            >
              <Icon className="w-5 h-5" />
              {!collapsed && <span>{item.label}</span>}
            </Button>
          );
        })}

        {/* Collapse Toggle */}
        {onToggleCollapse && (
          <Button
            variant="ghost"
            onClick={onToggleCollapse}
            className={cn(
              'w-full justify-start gap-3 h-11 px-3 mt-2',
              collapsed && 'justify-center px-2'
            )}
          >
            <ChevronLeft className={cn('w-5 h-5 transition-transform', collapsed && 'rotate-180')} />
            {!collapsed && <span>Collapse</span>}
          </Button>
        )}
      </div>
    </div>
  );
}
