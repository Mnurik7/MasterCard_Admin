import { 
  LayoutDashboard, 
  MessageSquare, 
  Receipt, 
  StickyNote, 
  Settings 
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { useTranslation } from '../../lib/localization';

interface MobileNavProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function MobileNav({ currentPage, onNavigate }: MobileNavProps) {
  const { t } = useTranslation();

  const navItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: t('nav.dashboard') },
    { id: 'chat', icon: MessageSquare, label: t('nav.chat') },
    { id: 'transactions', icon: Receipt, label: t('nav.transactions') },
    { id: 'notes', icon: StickyNote, label: t('nav.notes') },
    { id: 'settings', icon: Settings, label: t('nav.settings') },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[var(--color-surface)] border-t border-[var(--color-border)] safe-area-inset-bottom z-50">
      <div className="grid grid-cols-5 h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                'flex flex-col items-center justify-center gap-1 transition-colors',
                isActive 
                  ? 'text-[var(--color-primary-600)]' 
                  : 'text-[var(--color-text-tertiary)]'
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
