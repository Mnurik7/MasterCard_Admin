
  # Corporate Analytics Platform

  This is a code bundle for Corporate Analytics Platform. The original project is available at https://www.figma.com/design/Fy5PT4wiMmShRvQz7nPrtR/Corporate-Analytics-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  